"""Verify/reaggregate saved S30 per-run metrics; no raw-array rescoring or model execution.

Full original-array scoring source is retained under source/ and needs external inputs.
"""
import argparse,csv,json,math,statistics
from collections import defaultdict
from pathlib import Path
METRICS=('mse_std','mae_std','rmse_std','r2')
def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def close(a,b):assert math.isclose(float(a),float(b),rel_tol=1e-12,abs_tol=1e-12),(a,b)
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input-dir',type=Path,default=Path(__file__).resolve().parent)
    ap.add_argument('--output-dir',type=Path,default=None)
    a=ap.parse_args();d=a.input_dir
    runs=read(d/'pvdaq_two_site_run_metrics.csv')
    original=read(d/'pvdaq_two_site_sensitivity.csv')
    original_seed=read(d/'pvdaq_two_site_equal_weight_by_seed.csv')
    assert len(runs)==len({r['run_id'] for r in runs})==72
    expected={(site,h,backbone,path,seed) for site in ('2107','9068') for h in ('4','24') for backbone in ('patchtst','itransformer') for path in ('history','direct','residual') for seed in ('2024','2025','2026')}
    assert {(r['site'],r['horizon_hours'],r['backbone'],r['pathway'],r['seed']) for r in runs}==expected
    sitegroups=defaultdict(list);seedgroups=defaultdict(list)
    for r in runs:
        sitegroups[(r['site'],r['backbone'],r['horizon_hours'],r['pathway'])].append(r)
        seedgroups[(r['backbone'],r['horizon_hours'],r['pathway'],r['seed'])].append(r)
    taskgroups=defaultdict(list);calculated_seed=[]
    for key,rr in sorted(seedgroups.items()):
        assert len(rr)==2 and {r['site'] for r in rr}=={'2107','9068'}
        row=dict(zip(('backbone','horizon_hours','pathway','seed'),key))
        row.update({m:statistics.mean(float(r[m]) for r in rr) for m in METRICS})
        calculated_seed.append(row);taskgroups[key[:3]].append(row)
    seedmap={(r['backbone'],r['horizon_hours'],r['pathway'],r['seed']):r for r in original_seed}
    assert len(seedmap)==len(calculated_seed)==36
    for row in calculated_seed:
        key=tuple(str(row[k]) for k in ('backbone','horizon_hours','pathway','seed'))
        for m in METRICS:close(row[m],seedmap[key][m])
    calculated=[]
    for row in original:
        key=(row['backbone'],row['horizon_hours'],row['pathway'])
        rr=taskgroups[key] if row['aggregation']=='two_site_equal_weight' else sitegroups[(row['site'],)+key]
        assert len(rr)==3
        new={k:v for k,v in row.items() if not any(k==m+s for m in METRICS for s in ('_mean','_seed_sd'))}
        for m in METRICS:
            values=[float(r[m]) for r in rr]
            new[m+'_mean']=statistics.mean(values)
            new[m+'_seed_sd']=statistics.stdev(values)
            close(new[m+'_mean'],row[m+'_mean']);close(new[m+'_seed_sd'],row[m+'_seed_sd'])
        calculated.append(new)
    assert len(calculated)==36
    result={'status':'PASS','saved_run_rows':72,'site_and_task_mean_sd_rows':36,'same_seed_equal_site_rows':36,'metrics':list(METRICS),'training':False,'model_forward':False,'raw_predictions_rescored':False,'scope':'Independent stdlib reproduction of aggregate means/sample SD from the already verified per-run scores.'}
    if a.output_dir:
        a.output_dir.mkdir(parents=True,exist_ok=False)
        for name,rows in [('reaggregated_mean_sd.csv',calculated),('reaggregated_equal_site_by_seed.csv',calculated_seed)]:
            with (a.output_dir/name).open('w',encoding='utf-8',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
        (a.output_dir/'verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
