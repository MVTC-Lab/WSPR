"""Read-only CPU audit of raw PVDAQ 14200 and saved two-site predictions.

Writes only a NEW directory under WSPR_V17_SUBMISSION_PREFLIGHT. No torch import,
model invocation, fitting, interpolation, prediction clipping, or source changes.
"""
import argparse
import csv
import hashlib
import json
import platform
from pathlib import Path

import numpy as np
import pandas as pd

SPLITS = {'train': ('2020-01-01', '2021-10-01'),
          'validation': ('2021-10-01', '2022-01-01'),
          'test': ('2022-01-01', '2023-01-01')}
EXPECTED = {'train': (10081, 5116), 'validation': (2014, 1161), 'test': (7903, 4029)}
RAW_HASH = {2020: 'bfe9f99ee462d41fcd736333d1654325c6fa8cef2a11b8558808778f8632dcf7',
            2021: '5aa9d75f6d69e8073e4ac15c17515b6c3b815e976479d0372223818e97ce8b25',
            2022: '5eba94e980390a3a313422e5491be267140c07f45f35084054b21d2d4688a90f'}
META_HASH = '2fdb3dc9f39bf9b6aafa0c077c4af7d646e4935c102799daaf1465d57e11264a'
DOC_HASH = '1315d61eb027ada2862bb9a204c9c96fbc724ed61e278d667a5e8bc5f1979bac'
METRICS = ('mse_std', 'mae_std', 'rmse_std', 'r2')


def require(test, message):
    if not test:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def dump(path, data):
    def numpy_scalar(value):
        if isinstance(value, np.generic):
            return value.item()
        raise TypeError('Unsupported JSON value: ' + type(value).__name__)
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False,
                                   default=numpy_scalar), encoding='utf-8')


def csvout(path, rows):
    require(bool(rows), 'Refuse empty CSV: ' + str(path))
    pd.DataFrame(rows).to_csv(path, index=False, float_format='%.17g')


def quantiles(values, prefix):
    x = np.asarray(values, dtype=np.float64)
    if not len(x):
        return {prefix + k: None for k in ('min', 'p01', 'p50', 'p99', 'max', 'mean')}
    return dict(zip([prefix + k for k in ('min', 'p01', 'p50', 'p99', 'max', 'mean')],
                    [float(np.min(x)), float(np.quantile(x, .01)), float(np.median(x)),
                     float(np.quantile(x, .99)), float(np.max(x)), float(np.mean(x))]))


def audit_raw(base, work, out):
    notes = base / 'research_notes/independent_validation_feasibility_20260920'
    inputs = work / 'inputs/pvdaq'
    meta = inputs / '14200_system_metadata.json'
    require(sha(meta) == META_HASH, 'Metadata does not match frozen source')
    require(sha(inputs / 'official_metadata_recheck_20261106.json') == META_HASH,
            'Live official metadata differs from stored original')
    require(sha(inputs / 'official_documentation_recheck_20261106.md') == DOC_HASH,
            'Live official documentation differs from stored original')
    metadata = read(meta)
    metric = metadata['Metrics']['ac_power_meter_3105']
    meter = metadata['Meters']['Meter 0']
    require(metric['metric_id'] == 143230 and metric['units'] == 'kW'
            and metric['calc_scale'] == 1.0 and metric['calc_offset'] == 0.0
            and metric['aggregation_type'] == 'avg' and meter['time_interval'] == 'R',
            'Channel definition changed')
    provenance = []
    all_rows = []
    for year in (2020, 2021, 2022):
        name = '14200_all_channels_%d0101_%d1231.csv' % (year, year)
        path = inputs / name if year == 2021 else notes / 'samples' / name
        actual = sha(path)
        require(actual == RAW_HASH[year], 'Raw source hash mismatch ' + str(path))
        frame = pd.read_csv(path, usecols=['utc_measured_on', 'ac_power_meter_3105'])
        times = pd.to_datetime(frame['utc_measured_on'], utc=True, errors='raise')
        require(times.notna().all(), 'Missing raw UTC timestamps')
        values = frame['ac_power_meter_3105'].to_numpy(dtype=np.float64)
        provenance.append(dict(year=year, path=str(path), bytes=path.stat().st_size,
                               sha256=actual, expected_sha256=RAW_HASH[year], rows=len(frame),
                               url='https://oedi-data-lake.s3.us-west-2.amazonaws.com/pvdaq/csv/pvdata/system_id=14200/year=%d/%s' % (year, name),
                               location_origin='copied_existing_local_original_into_new_audit_inputs_then_uploaded'
                               if year == 2021 else 'preexisting_server_original_hash_matched_local_original',
                               source_local_original='D:/Times/research_notes/independent_validation_feasibility_20260920/samples/' + name,
                               first_utc=str(times.min()), last_utc=str(times.max()),
                               unparseable_timestamps=int(times.isna().sum()),
                               rows_outside_filename_year=int((times.dt.year != year).sum()),
                               finite_power_rows=int(np.isfinite(values).sum())))
        all_rows.append(pd.DataFrame({'source_file': name, 'source_row_1based_including_header': np.arange(len(frame)) + 2,
                                     'utc': times.dt.tz_convert(None), 'raw_ac_power_kw': values}))
    native = pd.concat(all_rows, ignore_index=True).sort_values('utc', kind='stable')
    native['off_grid'] = native.utc != native.utc.dt.floor('5min')
    # Match the established pipeline: off-grid rows first; all occurrences of
    # an on-grid duplicate timestamp are removed, without averaging duplicates.
    on_grid = native.loc[~native.off_grid]
    duplicate = on_grid.utc.duplicated(keep=False)
    native['duplicate_timestamp_all_occurrences'] = False
    native.loc[on_grid.index, 'duplicate_timestamp_all_occurrences'] = duplicate.values
    eligible = on_grid.loc[~duplicate]
    origin = pd.Timestamp('2020-01-01')
    end = pd.Timestamp('2023-01-01')
    regular = pd.date_range(origin + pd.Timedelta(minutes=5), end, freq='5min')
    values = pd.Series(eligible.raw_ac_power_kw.values, index=pd.DatetimeIndex(eligible.utc))
    values = values.reindex(regular)
    values = values.where(np.isfinite(values))
    native['utc_time'] = native.utc.dt.strftime('%Y-%m-%dT%H:%M:%SZ')
    local = native.utc.dt.tz_localize('UTC').dt.tz_convert(metadata['System']['timezone_code'])
    native['derived_local_time_with_offset'] = local.dt.strftime('%Y-%m-%dT%H:%M:%S%z')
    native['eligible_native_grid'] = (~native.off_grid & ~native.duplicate_timestamp_all_occurrences
                                      & (native.utc > origin) & (native.utc <= end)
                                      & np.isfinite(native.raw_ac_power_kw))
    csvout(out / 'pvdaq_14200_native_samples.csv', native.drop(columns='utc').to_dict('records'))
    groups = values.resample('1h', closed='right', label='right')
    n = groups.count()
    hourly_unrestricted = groups.mean()
    hourly = hourly_unrestricted.where(n == 12)
    all_native_per_hour = groups.apply(lambda s: json.dumps([None if pd.isna(v) else float(v) for v in s], separators=(',', ':')))
    hourly_table = pd.DataFrame({'utc_hour_end': hourly.index, 'raw_5min_ac_values_kw': all_native_per_hour.values,
                                'finite_native_sample_count': n.values, 'complete_hour': (n == 12).values,
                                'partial_hour_mean_kw_audit_only': hourly_unrestricted.values,
                                'mean_hourly_ac_power_kw': hourly.values,
                                'clipped_target_kw': np.maximum(hourly.values, 0.0),
                                'negative_complete_hour': (hourly < 0).values})
    hourly_table['split'] = ''
    hourly_table['negative_interval_id_within_split'] = ''
    hourly_table['split_negative_fraction_complete_hours'] = np.nan
    summaries, intervals = [], []
    for split, (lo, hi) in SPLITS.items():
        mask = (hourly_table.utc_hour_end > pd.Timestamp(lo)) & (hourly_table.utc_hour_end <= pd.Timestamp(hi))
        hourly_table.loc[mask, 'split'] = split
        chunk = hourly_table.loc[mask]
        complete = chunk.loc[chunk.complete_hour]
        negative = complete.loc[complete.negative_complete_hour]
        fraction = len(negative) / len(complete)
        hourly_table.loc[mask, 'split_negative_fraction_complete_hours'] = fraction
        flag = chunk.negative_complete_hour.astype(bool)
        ids = (flag != flag.shift(fill_value=False)).cumsum()
        negative_ids = ids[flag]
        for ordinal, (_, run) in enumerate(chunk.loc[flag].groupby(negative_ids, sort=True), start=1):
            tag = '%s_neg_%04d' % (split, ordinal)
            hourly_table.loc[run.index, 'negative_interval_id_within_split'] = tag
            intervals.append(dict(split=split, interval_id=tag, start_utc=str(run.utc_hour_end.iloc[0] - pd.Timedelta(hours=1)),
                                  end_utc=str(run.utc_hour_end.iloc[-1]), hours=len(run),
                                  min_kw=float(run.mean_hourly_ac_power_kw.min()),
                                  mean_kw=float(run.mean_hourly_ac_power_kw.mean()),
                                  negative_energy_kwh=float(-run.mean_hourly_ac_power_kw.sum())))
        summaries.append(dict(split=split, hour_end_rule='lo < t <= hi', start_utc=lo, end_utc=hi,
                              calendar_hours=len(chunk), complete_hours=len(complete), incomplete_hours=len(chunk)-len(complete),
                              negative_hours=len(negative), negative_fraction=fraction,
                              expected_complete_hours=EXPECTED[split][0], expected_negative_hours=EXPECTED[split][1],
                              exact_counts_match=(len(complete), len(negative)) == EXPECTED[split],
                              zero_clipping_delta_sum_kwh=float(-negative.mean_hourly_ac_power_kw.sum()),
                              **quantiles(negative.mean_hourly_ac_power_kw.values, 'negative_kw_')))
    hourly_table['derived_local_hour_end_with_offset'] = hourly_table.utc_hour_end.dt.tz_localize('UTC').dt.tz_convert(metadata['System']['timezone_code']).dt.strftime('%Y-%m-%dT%H:%M:%S%z')
    hourly_table['utc_hour_end'] = hourly_table.utc_hour_end.dt.strftime('%Y-%m-%dT%H:%M:%SZ')
    csvout(out / 'pvdaq_14200_negative_power_audit.csv', hourly_table.to_dict('records'))
    csvout(out / 'pvdaq_14200_negative_power_by_split.csv', summaries)
    csvout(out / 'pvdaq_14200_negative_intervals.csv', intervals)
    # A post-reconstruction comparison, not an input to reconstruction.
    old = pd.read_csv(notes / 'pv_14200_2020_2022_hourly_diagnostic.csv', index_col=0, parse_dates=True).iloc[:, 0]
    require(old.index.equals(hourly.index), 'Rebuilt hourly calendar differs from frozen original')
    delta = np.abs(old.values - hourly.values)
    max_delta = float(np.nanmax(delta))
    require(np.array_equal(np.isnan(old.values), np.isnan(hourly.values)) and max_delta < 1e-9,
            'Rebuilt raw hourly target differs from frozen original')
    offsets = local.dt.strftime('%z').value_counts().to_dict()
    unique_times = pd.DatetimeIndex(eligible.utc)
    diffs = pd.Series(unique_times).diff().dt.total_seconds().dropna()
    timeline = dict(raw_rows=len(native), off_grid_rows=int(native.off_grid.sum()),
                    duplicate_on_grid_rows_all_occurrences_dropped=int(duplicate.sum()),
                    native_grid_slots=len(regular), native_missing_or_nonfinite_slots=int(values.isna().sum()),
                    finite_native_slots=int(values.notna().sum()),
                    distinct_raw_step_seconds_counts={str(k): int(v) for k, v in diffs.value_counts().sort_index().items()},
                    derived_local_utc_offset_row_counts={str(k): int(v) for k, v in offsets.items()},
                    original_local_timestamp_column_present=False,
                    local_time_conversion_used_for_aggregation=False, interpolation=False,
                    hourly_slots=len(hourly), complete_hourly_slots=int(hourly.notna().sum()),
                    reconstructed_vs_old_hourly_max_abs_kw=max_delta,
                    hourly_original_file_sha256=sha(notes / 'pv_14200_2020_2022_hourly_diagnostic.csv'),
                    utc_clock_independently_verified=False,
                    time_rule='Source UTC column; (t-1h,t] contains 12 exact 5-minute endpoints. All duplicate on-grid rows discarded.')
    result = dict(raw_source_hashes=provenance, metadata_path=str(meta), metadata_sha256=META_HASH,
                  official_metadata_url='https://oedi-data-lake.s3.us-west-2.amazonaws.com/pvdaq/csv/system_metadata/14200_system_metadata.json',
                  official_documentation_url='https://github.com/openEDI/documentation/blob/main/pvdaq.md',
                  official_metadata_recheck_matches_original=True, official_documentation_recheck_sha256=DOC_HASH,
                  channel=metric, meter=meter, timezone=metadata['System']['timezone_code'],
                  negative_physical_cause='NEEDS_VERIFICATION', timeline=timeline, split_results=summaries,
                  negative_interval_count=len(intervals), longest_negative_interval_hours=max(r['hours'] for r in intervals))
    dump(out / 'pvdaq_14200_raw_audit_summary.json', result)
    return result


def metric_values(pred, truth):
    p, t = np.asarray(pred, dtype=np.float64), np.asarray(truth, dtype=np.float64)
    require(p.shape == t.shape and p.size > 0 and np.isfinite(p).all() and np.isfinite(t).all(), 'Invalid arrays')
    e = p - t
    mse = float(np.mean(e ** 2))
    denom = float(np.sum((t - t.mean()) ** 2))
    require(denom > 0, 'Undefined R2 must not be silently filled')
    return dict(mse_std=mse, mae_std=float(np.mean(np.abs(e))), rmse_std=float(np.sqrt(mse)),
                r2=float(1 - np.sum(e ** 2) / denom))


def audit_two_site(base, out):
    execution = base / 'papers-with-code/datasets/PV/hrrr_point_accel_v3/independent_execution_v1_20260927'
    package, results = execution / 'package', execution / 'results'
    lock = read(package / 'execution_lock.json')
    lock_hash = sha(package / 'execution_lock.json')
    provenance = read(results / 'analysis/provenance.json')
    scalers = read(package / 'train_only_scalers.json')
    manifest = pd.read_csv(package / 'planned_run_manifest.csv', dtype=str).to_dict('records')
    require(len(manifest) == 108 and len({r['run_id'] for r in manifest}) == 108, 'Run matrix is not 108 unique runs')
    require({(r['site'], r['horizon_hours'], r['backbone'], r['pathway'], r['seed']) for r in manifest}
            == {(s, h, b, p, k) for s in ('2107', '9068', '14200') for h in ('4', '24')
                for b in ('patchtst', 'itransformer') for p in ('history', 'direct', 'residual')
                for k in ('2024', '2025', '2026')}, 'Factorial matrix mismatch')
    rows = [r for r in manifest if r['site'] in ('2107', '9068')]
    caches, cache_hashes, audited, hashes = {}, {}, [], []
    for row in rows:
        run_id = row['run_id']
        directory = results / 'runs' / run_id
        summary = read(directory / 'summary.json')
        require(sha(directory / 'summary.json') == provenance['run_summary_sha256'][run_id], 'Summary provenance mismatch ' + run_id)
        require(summary['status'] == 'PASS' and summary['run_id'] == run_id
                and summary['execution_lock_sha256'] == lock_hash, 'Wrong completed run identity')
        file_hashes = {}
        for name in ('config.json', 'test_predictions.npz', 'metrics.json', 'selection.json'):
            value = sha(directory / name)
            require(value == summary['artifacts_sha256'][name], 'Run artifact hash drift ' + run_id + '/' + name)
            file_hashes[name] = value
            hashes.append(dict(run_id=run_id, path=str(directory / name), sha256=value, verified_against='run_summary_artifacts_sha256'))
        config = read(directory / 'config.json')
        require(config['manifest'] == row, 'Configuration/manifest mismatch')
        group = (row['site'], row['horizon_hours'])
        cache_path = package / 'cache' / ('%s_h%s_test.npz' % group)
        if group not in caches:
            cache_hashes[str(cache_path)] = sha(cache_path)
            expected_cache = lock['package_sha256']['cache/' + cache_path.name]
            require(cache_hashes[str(cache_path)] == expected_cache, 'Frozen cache drift')
            with np.load(cache_path, allow_pickle=False) as z:
                caches[group] = {k: z[k] for k in z.files}
        cache = caches[group]
        with np.load(directory / 'test_predictions.npz', allow_pickle=False) as z:
            arrays = {k: z[k] for k in z.files}
        for a, b in (('true_std', 'target_scaled'), ('true_kw', 'target_kw'), ('raw_kw', 'target_raw_kw'),
                     ('origin_ns', 'origin_ns'), ('target_ns', 'target_ns')):
            require(np.array_equal(arrays[a], cache[b]), 'Truth/time is not paired ' + run_id + '/' + a)
        mean, scale = scalers[row['site']]['power']['mean'][0], scalers[row['site']]['power']['scale'][0]
        require(np.array_equal(arrays['pred_kw'], arrays['pred_std'] * scale + mean), 'Prediction scale mismatch')
        require(np.array_equal(arrays['true_kw'], np.maximum(arrays['raw_kw'], 0)), 'Target clipping convention changed')
        metrics = metric_values(arrays['pred_std'], arrays['true_std'])
        recorded = read(directory / 'metrics.json')
        require(all(metrics[m] == recorded[m] for m in METRICS), 'Recomputed metrics do not exactly match original ' + run_id)
        require(recorded['prediction_postprocessing'] == 'none' and recorded['scale'] == 'per_site_train_standardized', 'Scale or postprocessing changed')
        audited.append(dict(run_id=run_id, site=row['site'], horizon_hours=int(row['horizon_hours']),
                            backbone=row['backbone'], pathway=row['pathway'], seed=int(row['seed']),
                            windows=len(arrays['pred_std']), scored_window_lead_cells=arrays['pred_std'].size,
                            **metrics, pred_sha256=file_hashes['test_predictions.npz']))
    require(len(audited) == 72, 'Two-site predictions are incomplete')
    csvout(out / 'pvdaq_two_site_run_metrics.csv', audited)
    csvout(out / 'pvdaq_two_site_verified_artifact_hashes.csv', hashes)
    frame = pd.DataFrame(audited)
    groupcols = ['backbone', 'horizon_hours', 'pathway']
    task_seed = frame.groupby(groupcols + ['seed'], as_index=False)[list(METRICS)].mean()
    csvout(out / 'pvdaq_two_site_equal_weight_by_seed.csv', task_seed.to_dict('records'))
    output = []
    for level, keys, table in (('site_seed_mean', ['site'] + groupcols, frame),
                                ('two_site_equal_weight', groupcols, task_seed)):
        for key, group in table.groupby(keys, sort=True):
            require(len(group) == 3 and set(group.seed) == {2024, 2025, 2026}, 'Incomplete three-seed group')
            values = dict(zip(keys, key))
            record = dict(aggregation=level, site=values.get('site', '2107+9068'), **{k: values[k] for k in groupcols},
                          n_sites=1 if level == 'site_seed_mean' else 2, n_seeds=3, std_ddof=1,
                          scale='per_site_train_standardized', excluded_site='14200')
            for metric in METRICS:
                record[metric + '_mean'] = float(group[metric].mean())
                record[metric + '_seed_sd'] = float(group[metric].std(ddof=1))
            output.append(record)
    csvout(out / 'pvdaq_two_site_sensitivity.csv', output)
    comparisons = []
    for (backbone, horizon), g in task_seed.groupby(['backbone', 'horizon_hours']):
        for candidate, reference in (('direct', 'history'), ('residual', 'history'), ('residual', 'direct')):
            c = g.loc[g.pathway.eq(candidate)].sort_values('seed')
            r = g.loc[g.pathway.eq(reference)].sort_values('seed')
            row = dict(backbone=backbone, horizon_hours=int(horizon), candidate=candidate, reference=reference)
            for metric in METRICS:
                cv, rv = c[metric].to_numpy(), r[metric].to_numpy()
                row[metric + '_candidate_mean'] = float(cv.mean())
                row[metric + '_reference_mean'] = float(rv.mean())
                row[metric + '_candidate_minus_reference'] = float((cv-rv).mean())
                if metric != 'r2':
                    row[metric + '_relative_improvement_pct'] = float((rv.mean()-cv.mean())/rv.mean()*100)
            comparisons.append(row)
    csvout(out / 'pvdaq_two_site_pathway_comparisons.csv', comparisons)
    summary = dict(status='PASS', completed_saved_predictions_scored=72, excluded_saved_runs=36,
                   excluded_site='14200', retained_sites=['2107', '9068'], matrix='2 sites x 2 horizons x 2 backbones x 3 pathways x 3 seeds',
                   scale='per-site train-only standardized power; no inverse-unit pooling or rescaling',
                   scoring='Flatten all eligible saved window/lead cells per run; retain overlapping appearances as original.',
                   aggregation='Site: arithmetic mean and sample SD over 3 seeds. Task: equal mean of two sites for the SAME seed; then arithmetic mean and sample SD of 3 seed means.',
                   rmse='Each per-run RMSE is sqrt(per-run MSE); task RMSE averages those values, not sqrt(task mean MSE).',
                   r2='Each per-run R2 uses global flattened truth mean; site/task R2 is arithmetic mean of per-run R2, not pooled-sample R2.',
                   window_counts={s + '_h' + str(h): int(g.windows.iloc[0]) for (s,h),g in frame.groupby(['site','horizon_hours'])},
                   frozen_cache_sha256=cache_hashes, execution_lock_sha256=lock_hash,
                   exact_original_metrics_reproduced_all_72=True, prediction_hashes_verified_against_original_summaries=True,
                   summary_hashes_verified_against_original_analysis_provenance=True,
                   checkpoints_loaded_or_rehashed=False, training_performed=False,
                   task_rows=[r for r in output if r['aggregation'] == 'two_site_equal_weight'])
    dump(out / 'pvdaq_two_site_sensitivity_summary.json', summary)
    return summary


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--base', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    base, out = Path(args.base), Path(args.out)
    work = base / 'WSPR_V17_SUBMISSION_PREFLIGHT'
    require(work.resolve() in out.resolve().parents, 'Output must remain in isolated audit workspace')
    require(not out.exists(), 'Refuse to overwrite a previous audit directory')
    out.mkdir(parents=True)
    raw = audit_raw(base, work, out)
    sensitivity = audit_two_site(base, out)
    dump(out / 'execution_summary.json', dict(status='PASS', host=platform.node(), python=platform.python_version(),
         numpy=np.__version__, pandas=pd.__version__, script_sha256=sha(__file__), raw_audit_counts_match=all(r['exact_counts_match'] for r in raw['split_results']),
         original_sources_modified=False, gpu_used=False, training=False, new_sensitivity_runs=len(sensitivity['task_rows'])))
    with (out / 'SHA256SUMS').open('w', encoding='utf-8') as f:
        for path in sorted(out.iterdir()):
            if path.is_file() and path.name != 'SHA256SUMS':
                f.write(sha(path) + '  ' + path.name + '\n')
    print(json.dumps({'status':'PASS', 'split_counts': [{k:r[k] for k in ('split','complete_hours','negative_hours','negative_fraction','exact_counts_match')} for r in raw['split_results']],
                      'native_rows':raw['timeline']['raw_rows'], 'negative_intervals':raw['negative_interval_count'],
                      'longest_negative_interval_hours':raw['longest_negative_interval_hours'],
                      'two_site_verified_runs':sensitivity['completed_saved_predictions_scored'],
                      'out':str(out)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
