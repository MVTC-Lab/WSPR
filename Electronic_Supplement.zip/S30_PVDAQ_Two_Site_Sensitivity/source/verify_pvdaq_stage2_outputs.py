"""Independent output checks using csv/statistics; no model imports or training."""
import argparse
import csv
import hashlib
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def rows(p):
    with Path(p).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def close(a, b):
    assert math.isclose(float(a), float(b), rel_tol=1e-12, abs_tol=1e-12), (a, b)


def main(base):
    work = base / 'WSPR_V17_SUBMISSION_PREFLIGHT'
    out = work / 'audit/pvdaq_raw_two_site_20261106_v2'
    package = base / 'papers-with-code/datasets/PV/hrrr_point_accel_v3/independent_execution_v1_20260927/package'
    lock = json.loads((package / 'execution_lock.json').read_text())
    file_checks = {}
    for name in ('planned_run_manifest.csv', 'train_only_scalers.json'):
        actual = sha(package / name)
        assert actual == lock['package_sha256'][name], name
        file_checks[name] = actual
    metric_names = ('mse_std', 'mae_std', 'rmse_std', 'r2')
    run = rows(out / 'pvdaq_two_site_run_metrics.csv')
    assert len(run) == len({r['run_id'] for r in run}) == 72
    by_site, by_task_seed = defaultdict(list), defaultdict(list)
    for r in run:
        by_site[(r['site'], r['backbone'], r['horizon_hours'], r['pathway'])].append(r)
        by_task_seed[(r['backbone'], r['horizon_hours'], r['pathway'], r['seed'])].append(r)
    by_task = defaultdict(list)
    for key, group in by_task_seed.items():
        assert len(group) == 2 and {r['site'] for r in group} == {'2107', '9068'}
        by_task[key[:3]].append({m: statistics.mean(float(r[m]) for r in group) for m in metric_names})
    output = rows(out / 'pvdaq_two_site_sensitivity.csv')
    assert len(output) == 36
    for r in output:
        key = (r['backbone'], r['horizon_hours'], r['pathway'])
        group = by_task[key] if r['aggregation'] == 'two_site_equal_weight' else by_site[(r['site'],) + key]
        assert len(group) == 3
        for m in metric_names:
            values = [float(a[m]) for a in group]
            close(r[m + '_mean'], statistics.mean(values))
            close(r[m + '_seed_sd'], statistics.stdev(values))
    negative_counts = defaultdict(lambda: [0, 0])
    hourly = rows(out / 'pvdaq_14200_negative_power_audit.csv')
    assert len(hourly) == 26304
    for r in hourly:
        x = json.loads(r['raw_5min_ac_values_kw'])
        assert len(x) == 12
        complete = all(v is not None and math.isfinite(v) for v in x)
        assert complete == (r['complete_hour'] == 'True')
        assert sum(v is not None for v in x) == int(r['finite_native_sample_count'])
        if complete:
            average = math.fsum(x) / 12
            close(average, r['mean_hourly_ac_power_kw'])
            close(max(average, 0), r['clipped_target_kw'])
            assert (average < 0) == (r['negative_complete_hour'] == 'True')
            negative_counts[r['split']][0] += 1
            negative_counts[r['split']][1] += int(average < 0)
        else:
            assert r['mean_hourly_ac_power_kw'] == r['clipped_target_kw'] == ''
    assert dict(negative_counts) == {'train': [10081, 5116], 'validation': [2014, 1161], 'test': [7903, 4029]}
    result = dict(status='PASS', verifier_sha256=sha(__file__), locked_package_file_hashes=file_checks,
                  unique_prediction_run_rows=72, site_and_task_mean_sd_rows=36,
                  hourly_rows_independently_checked_from_saved_12_native_values=26304,
                  negative_counts=dict(negative_counts), std_definition='sample SD, ddof=1',
                  statistics_implementation='stdlib csv/math/statistics; independent of pandas groupby',
                  training=False, gpu=False, originals_modified=False)
    path = work / 'audit/pvdaq_stage2_independent_checks.json'
    assert not path.exists(), 'Refuse overwrite'
    path.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result))


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--base', required=True)
    main(Path(ap.parse_args().base))
