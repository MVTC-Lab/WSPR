# Frozen parameter-count audit v1

- Analysis type: read-only audit of representative frozen checkpoints; no training or model execution.
- Coverage: History-only, Direct-NWP, and Residual-NWP for both backbones, both datasets, and both forecast tasks.
- Total trainable parameters are reconstructed from checkpoint tensors after excluding registered buffers (`position_embedding.pe`, batch-normalization running statistics, and `num_batches_tracked`).
- Historical forecast-head parameters are `head.linear.*` for the PatchTST-based backbone and `projection.*` for iTransformer, with an optional `backbone.` prefix.
- NWP integration-module parameters are all `direct_head.*` tensors for Direct-NWP and all `adapter.*` tensors for Residual-NWP; History-only has no NWP integration module.
- NWP output-head parameters are `direct_head.target_head.*` for Direct-NWP and the residual/gate output tensors (`adapter.delta_head.*`, `adapter.reliability_head.*`, `adapter.gate_floor_*`, and `adapter.max_residual_logit`) for Residual-NWP.
- One representative checkpoint is read per architecture/dataset/task cell. Parameter counts are architectural quantities and therefore do not depend on site, region, or seed.

