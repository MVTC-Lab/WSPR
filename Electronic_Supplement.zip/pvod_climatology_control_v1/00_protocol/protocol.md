# Protocol: PVOD training-derived calendar-climatology NWP control v1

- Protocol ID: `pvod_calendar_climatology_control_v1`
- Protocol date: 2026-09-19 (Asia/Shanghai)
- Status: DRAFT until the preparation command creates `protocol_lock.json`;
  that lock, not this draft label, records the actual pre-outcome timestamp and hashes.
- Role: mechanism control; never a model-selection or tuning experiment
- New fits: exactly **120**

## Question

Does the observed behavior of the WSPR-history-backbone Direct-NWP and
Residual-NWP pathways require weather-specific future information, or can it
also arise when the decoder receives a training-derived calendar climatology?

This control does not establish operational NWP availability and does not
repair the retrospective provenance of the legacy PVOD prefix.  All outcomes,
including unfavorable and null outcomes, must be retained.

## Isolation and preserved information

Each fit uses two aligned files through the experiment-local paired loader:

1. The unchanged station `PVOD_pre80` file supplies **all encoder history**.
2. A derived file supplies only the eight decoder-side future NWP channels.

The derived file has the same ten columns, row count, row order, timestamps,
and `OT` values as its source.  Only the eight named NWP fields differ.  The
paired loader fits `StandardScaler` on the original source training rows and
uses that same scaler for original history, climatology future covariates, and
the unchanged target.  Thus dates, targets, historical values, split
boundaries, and sample windows remain matched to the prepared-NWP reference.

The shared `data_provider`, frozen model files, existing checkpoints,
registries, evidence packages, manuscripts, and prior v5/v6 directories are
not edited.

## Leakage-safe climatology construction

For a station file with `N` rows, the only fitting rows are
`[0, floor(0.7 N))`, exactly matching `Dataset_Custom`'s training partition.
Validation and test rows, including their NWP values, are never used to fit a
median, choose a fallback, select a hyperparameter, or alter the protocol.

For each of the eight NWP variables independently:

1. Primary value: median by `(calendar month, quarter-hour-of-day)` on training
   rows only.  Quarter-hour is `4 * hour + floor(minute / 15)` in `[0, 95]`.
2. First fallback: training-only median by quarter-hour-of-day.
3. Final fallback: training-only global median for that variable.

The rule is applied without outcome-dependent smoothing.  Counts for all three
levels are recorded by station, variable, and train/validation/test target
partition.  Fitted tables and actual input/output SHA-256 hashes are retained.
Every derived value must be finite.  Raw NWP vectors must not be all zero, and
the exact scaled 16- and 96-step decoder windows must all satisfy the models'
`mean(abs(NWP)) > 1e-6` availability rule.  Any failure blocks training.

## Locked matrix

- Dataset: PVOD `confirmatory_splits/PVOD_pre80`.
- Units: station00 through station09.
- Input length: 96.
- Horizons: 16 and 96.
- Seeds: 2024, 2025, 2026.
- Backbone family: WSPR history backbone (PatchTST-backed).
- Pathways/models:
  - Direct-NWP: `TimeMixer_7_DirectNWP_OptMatched`.
  - Residual-NWP: `TimeMixer_7` with `wspr_ablation=none`.
- Fits: `10 stations x 2 horizons x 3 seeds x 2 pathways = 120`.

Every row is enumerated in `run_manifest.csv`; none may be dropped based on a
result.

## Locked training configuration

| Item | Value |
|---|---|
| task / features / target | long-term forecast / MS / OT |
| frequency | `t` (15-minute source timestamps) |
| channels | 9 input, 9 decoder, 9 output; 8 known future |
| future target | always zero-masked by the existing experiment class |
| d_model / d_ff | 128 / 256 |
| heads / encoder layers | 8 / 2 |
| dropout | 0.05 |
| loss / optimizer | MSE / Adam |
| initial LR / scheduler | 0.001 / repository `type1` |
| batch size | 32 |
| epoch cap / patience | 20 / 5 |
| AMP | enabled |
| checkpoint selection | minimum validation MSE |
| residual L1 / physics loss | 0.0 / 0.0 |

No per-station, per-horizon, per-pathway, or result-dependent tuning is
permitted.

## Locked analysis

The existing read-only registry
`papers/WSPR_AppliedEnergy/evidence/data/all_results.csv` supplies the matched
prepared-NWP reference rows `PatchTST_Direct` and `PatchTST_Residual`.  Its hash
is part of the protocol lock.  Seeds are averaged within station before any
comparison; station (`n=10`) is the aggregation and resampling unit. Spatial
independence among stations has not been established; seeds are not independent
physical units.

Analysis is descriptive: report all seed-level metrics, station seed means and
sample SD (ddof=1), task station means, paired absolute and relative effects,
median paired effects, and win/tie/loss (absolute metric tolerance 1e-12).
There is no new significance-test family and no p-value calculation.
Include the original `PatchTST` History-only rows from
`experiments/wspr_q1/history_only_confirmatory/02_analysis/all_results.csv`;
its hash is also locked. Compare each climatology pathway with its matched
prepared-NWP pathway and History-only, and compare the two climatology pathways.
For every MSE/MAE paired contrast, use 10,000 paired station-bootstrap draws
with seed 20260919, reporting 95% percentile intervals (2.5/97.5 percentiles).
These are pointwise descriptive intervals without multiplicity adjustment.
The same ordered station resampling indices are used across all contrasts.
Positive `(candidate - reference) / reference` means candidate is worse.
The task relative effect is the mean of station-specific ratios, which is
not generally the ratio of task means. R2 remains descriptive.
All new and reference MSE/MAE/RMSE/R2 are recomputed in float64 from saved
prediction arrays. Before accepting reference arrays, the repository's
original `MAE, MSE, RMSE, MAPE, MSPE` save order and registry MSE/MAE are
verified against its native metric function (`rtol=1e-7`, `atol=1e-8`).
The original frozen tables remain untouched. New control targets must be
exactly equal to the corresponding original target arrays before aggregation.

## Stop conditions

No training may start unless the independent audit passes all of the following:

1. protocol, manifest, expected-output, implementation, and frozen-source
   hashes match `protocol_lock.json`;
2. exactly ten source/control pairs exist and their data hashes match the data
   lock;
3. each climatology is independently recomputed from training rows only;
4. date, target, schema, row count, and row order are unchanged;
5. paired-loader history equals the scaled original source, not the control;
6. every H=16/H=96 decoder window keeps NWP availability active;
7. all 120 manifest rows are unique and match the locked configuration.
8. all 180 original reference prediction/truth/metric/checkpoint files match
   their locked hashes and the original metric order is verified;
9. original station00, seed2024, Direct/Residual checkpoints at both horizons
   replay the complete original test arrays on CUDA/AMP with exactly equal
   truths and maximum absolute prediction difference no greater than `2e-5`.
   This pre-fixed replay tolerance matches the earlier suffix preflight and
   permits hardware arithmetic variation; actual differences are reported.

Full training additionally requires explicit authorization through
`CONFIRM_FULL=YES`.  Protocol preparation, data preparation, and audits do not
authorize training.

## Entrypoints (run from the project root on the configured Linux server)

```bash
/home/xingyu/miniconda3/envs/xy-3.8/bin/python scripts/wspr_q1/prepare_pvod_climatology_control_v1.py --prepare-data
/home/xingyu/miniconda3/envs/xy-3.8/bin/python scripts/wspr_q1/audit_pvod_climatology_control_v1.py --device cuda:0
CONFIRM_FULL=YES /home/xingyu/miniconda3/envs/xy-3.8/bin/python scripts/wspr_q1/run_pvod_climatology_control_v1.py --device cuda:0
/home/xingyu/miniconda3/envs/xy-3.8/bin/python scripts/wspr_q1/analyze_pvod_climatology_control_v1.py
```

The runner supports disjoint `--shard-index 0 --shards 2` and
`--shard-index 1 --shards 2` processes on different GPUs. Each run directory is
claimed exclusively and any failed fit is retained, never silently retrained.
The runner reuses the frozen experiment class's complete training loop, Adam,
AMP, shuffled training/validation loaders, LR schedule, and minimum validation
MSE checkpoint selection. It overrides only the data provider, device selection,
and isolated prediction saving. Future target is zero-masked by the existing
decoder builder. `physics_loss_weight=0` is inactive for these model versions.
Independent model/loader/decoder checks run before any fit. The mechanism
control retains calendar information and is not an information-free null.
The first authorized `--limit 1` fit can estimate runtime without changing any
configuration; normal re-entry verifies and skips that completed fit. Do not
interpret one run or partial shards as a completed experiment. No aggregated
results are released until all 120 rows pass verification. This matrix covers
only the WSPR-history backbone on PVOD, not iTransformer or GEFCom.
