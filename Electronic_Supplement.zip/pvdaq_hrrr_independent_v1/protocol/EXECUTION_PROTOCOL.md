# Independent validation execution v1 — 2026-09-27

Internal prospective execution record, not an external preregistration, a result,
or human scientific sign-off. The user authorized: “进行就行了，直到全部跑完”.
This supersedes the *permission state*, not the scientific content, of the unchanged
preparation protocol. The preparation snapshot remains an immutable historical record.

## Locked design and boundary

Use the previously audited 17,635 windows, frozen dates, three sites, H=4/24 h,
96 h common historical power, seven future HRRR fields, and per-site train-only
scalers. Primary target: max(complete-hour mean measured AC power, 0), not gross
generation. Seven historical channels are constant standardized-space padding.
Nominal forecast initialization is not demonstrated operational availability.
PV hour-ending averages and instantaneous forecast values have different support.
No further downloads, model edits, imputation, clipping of predictions, split
changes, tuning, or selection on test performance are authorized by this execution.

108 fits: 3 sites × 2 horizons × 2 backbones × 3 pathways × 3 seeds. The initial
12 are site 2107, seed 2024, all horizons/backbones/pathways, with the identical
full epoch budget. They count ONCE toward 108. The engineering gate requires all
artifacts to be complete, finite, hash-bound and paired; it does not require a
favorable accuracy ranking. After that gate, run the remaining 96 automatically.

## Training implementation

All settings come from the unchanged 108-row preparation manifest. CPU is used
for data preparation and analysis; neural training requires the specified Linux
conda/PyTorch environment and CUDA AMP. One subprocess per fit; use only GPUs
with no active compute process, <1 GiB reported allocation and <10% utilization
at dispatch. Never kill another workload. Default scheduling may use up to two
idle GPUs, one fit each; no multi-GPU training or hyperparameter change.

Adam defaults are made explicit: betas=(0.9,0.999), eps=1e-8, weight_decay=0,
amsgrad=False. MSE on the last output channel only, batch size 32, all tail
batches retained, no gradient clipping, AMP GradScaler defaults. Nonfinite
forward loss or parameters fail closed. AMP overflow skips are counted; an
epoch with no successful update fails. Unused trainable padding-output
parameters are not mistaken for a bug. Gradient-bearing parameter names and
counts are recorded per epoch; no parameters are frozen or un-frozen here.

20 epochs maximum; patience=5; strict lower validation MSE selects a checkpoint,
ties retain the earlier epoch. Validation MSE is element-weighted over all
validation windows. Test labels are loaded only after final checkpoint selection.
Type1 LR after completed epoch e (1-based) is 0.001*0.5**(e-1), matching the
existing schedule. Shuffle is a deterministic per-epoch seeded NumPy permutation;
this is an explicit new runner, not a claim of bitwise reproduction of old runs.
Python/NumPy/PyTorch seeds are fixed; cuDNN benchmark off, deterministic on,
TF32 off. Hardware/library nondeterminism outside those controls is not ruled out.

Atomic epoch checkpoints contain model, best-model state, optimizer, AMP, RNG,
canonical epoch history and validation selection state. Interrupted partial
epochs restart from the last complete checkpoint. Attempts and errors are kept;
successful runs are verified and skipped, never silently overwritten. Only
signal-interrupted workers can retry automatically (maximum three attempts);
numerical, integrity or code exceptions stop the queue for inspection. Server
reboot requires reissuing the launch command; SSH window closure does not.

## Evaluation and analysis (frozen before fits)

Store every seed's standardized predictions, exact double-precision targets,
raw and clipped kW targets, origins and lead times. Do not ensemble predictions.
Named metrics: standardized MSE/MAE/RMSE/R2, physical MAE/RMSE kW. R2 is null
when target variance is zero. No MAPE, p values, significance marks, or unverified
capacity normalization. Report seed-first mean and sample SD, all three sites,
equal-site task means and observed ranges. Negative paired candidate-reference
deltas favor candidate. Report Residual–History, Direct–History, Residual–Direct.
Report both mean-of-site relative improvements and ratio-of-site-means.

Descriptive conditional within-site time uncertainty: complete UTC origin-day
calendar of 2022 (365 days including empty days), paired circular 7-day blocks,
10,000 draws, seed 20260927. Repeat with fixed 14-day blocks. Use exactly the
same day resamples for all sites/backbones/pathways/seeds for each block size.
Keep whole origin/lead vectors and weight by sampled target-element counts;
average independently computed seed losses. 95% percentile intervals describe
conditional time variability, not three-site population inference or multiplicity
controlled evidence. Report both MSE and MAE differences.

Two deterministic controls on identical test windows: (1) yesterday's same UTC
hour, which is inside the historical window for H<=24; (2) train-only month×hour
clipped-power climatology, fallback to hour then global train mean only if empty.
These make 12 evaluation cells, not additional neural fits. Raw-AC evaluation
sensitivity reuses the SAME clipped-trained predictions against raw targets;
it is explicitly not raw-target retraining. Lead-wise MSE/MAE are descriptive.

## Gates and provenance

Execution lock binds raw/preparation provenance, portable cache files, scalers,
matrix, original model hashes, successful forward evidence, this protocol,
training/analysis/launcher code and local unit-test report. Machine pass does
not assert human verification. Cache construction may examine held-out values
only for integrity and the preauthorized target views; it makes no selection.
The local test suite is synthetic engineering evidence, never research results.
Completion requires 108 unique verified runs plus full analysis PASS. Manuscript
and old experiments remain untouched. Unfavorable outcomes must be retained.
