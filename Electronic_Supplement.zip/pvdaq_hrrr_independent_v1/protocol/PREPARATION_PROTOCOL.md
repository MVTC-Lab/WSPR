# PVDAQ–HRRR 独立验证：训练前准备协议 v1

日期：2026-09-27。状态：**作者已确认目标及历史信息；设计记录和数据检查阶段，尚非训练解锁文件。**

这是内部非临床时序预测研究协议，不是论文结果、注册证明或投稿就绪声明。
所有已有模型结果、原始数据、冻结日期及论文均保持不变。机器核验不代替作者科学审核。
本轮只运行无模型的数据加载测试，不启动 12 次试运行或 108 次正式训练。

## 1. 已有证据与作者决定

- 全量已解码记录 QC：710,080 条字段记录；本轮不重新下载或解码 GRIB。[claim:C001] [evidence:E001]
- 原冻结时间切分继续保留，不能以模型效果调整日期。[claim:C002] [evidence:E002]
- 既有研究规划是 108 次主实验，种子沿用 2024、2025、2026。[claim:C003] [evidence:E003,E004]
- 用户本轮明确确认零截断实测 AC 功率、三条路径共同的历史功率输入。[claim:C004] [evidence:E006]

运行目录中的 `source_manifest.json`、`claims.csv` 和 `consistency_manifest.json`
保存支持位置与哈希。人类最终证据验证标记仍为待完成；不得把机器检查写成导师已经签字。
Solar Energy 投稿政策的当前核验留到论文整合阶段；本工程检查不声称满足期刊全部要求。

## 2. 目标、缺测与时钟：已明确

主目标为 `P_plus(t) = max(P_raw_hourly(t), 0)`，单位 kW。
先按已核验规则形成完整小时均值，再截零；不是先把 5/15 min 负数截零后平均。
历史功率与预测标签使用相同定义。原始小时功率只读保留；另存各站点/切分的负值计数、
截零造成的总量差异；窗口内重复出现的小时与唯一时钟小时分别计数。
这称为“零截断实测 AC 功率”，不能称为真实 gross generation 的重建。

不填补缺测，不插值，不将缺测标成零，不增加异常值剔除规则；冻结窗口不改变。
保留既有 UTC、DST 排除及各站点原始区间左右对齐规则。

原始 AC 视图仅用于预先说明的数据敏感性检查。本轮不创建第二套训练矩阵；
未来若要做“原始 AC 为目标的重新训练”，必须单独记录前置协议与预算。
用截零目标训练的预测去对照原始 AC，最多是评价口径敏感性，不是重新训练证据。

## 3. HRRR 信息时间：明确降级边界，不伪造延迟

研究定位为 **archived forecast-vintage validation under nominal initialization**。
每个窗口固定 `init = origin`，仅取该批次 leads 1..H；保留 init、lead、valid 三个维度。
同一 valid time 上不同批次的预报不能混合，也不能挑更准的一条。
不把 `init=origin` 称为预测文件在该时刻已发布；也未重建实时 PV 遥测延迟。

本轮不猜测 1 h、2 h 或其他发布日期延迟，不挪用“前一个批次”冒充已审计业务场景。
若未来开展 release-lag 实验，必须重新核验批次/提前量覆盖并单独冻结，不算本方案已有证据。
HRRR 的 valid-time 瞬时量与 PV 截至该时刻的完整小时平均值属于小时末配对，非相同时间支持。
DSWRF 保持瞬时 W/m²，不去累积；U/V 保留原始网格相对分量，不称为东西/南北分量。

## 4. 冻结样本与共同输入

- 站点：2107、9068、14200；history=96 h；horizon=4 h、24 h；4 个 UTC 起报时刻。
- Train：2020-01-01 至 2021-10-01；validation：2021 Q4；test：2022。
- 完整历史与未来目标区间均包含在所属切分内；不是通用 70/10/20 划分。
- 三条路径均只用共同的过去功率和预先可知的 UTC 日历特征；Direct、Residual 才能访问未来 HRRR。
- 日历特征沿用原 hourly `timeF` 公式；具体骨干是否消费这些特征以原代码为准，不改模型。
- HRRR 顺序固定 `TMP, RH, UGRD, VGRD, PRES, TCDC, DSWRF`；共 7 个已核验变量。

现有模型接口限定 `known_future_dim <= enc_in - 1`。为保留原模型实现，候选输入张量采用
`enc_in=dec_in=c_out=8`：历史前 7 个槽固定为标准化空间的 0，仅末槽有功率；这些是显式
**结构填充槽**，不是观测值、气象插值或缺测天气估计。三条路径使用完全相同历史张量。
Direct/Residual 的 decoder 前 7 槽为真实同批次 HRRR；末槽严格为 0。History decoder 全零。
`label_len=0`。训练只监督末槽功率；不能训练预测其余填充槽。

这是“共同历史功率条件下的未来 NWP 融合比较”，不同于旧数据多变量历史输入。
结构填充可能影响特定骨干的数值行为，必须在服务器前向检查中核验并在方法中披露；
不能声称它与删掉通道的单变量架构完全相同。若检查不通过，先修改工程协议，不按测试分数改设计。

## 5. Train-only 标准化与物理单位

每站点一组参数，两个 horizon、两种骨干和三条路径共享：

1. Power scaler：只使用该站点训练日期范围内全部有限、完整的小时均值；每时钟小时计一次。
   小时标签是区间终点，所以范围是 `(train_start, train_end]`。先按已确认目标截零再拟合。
2. NWP scaler：只使用已接纳训练窗口的真实 HRRR，按 `(site, init, lead)` 去掉两个 horizon
   的重复视图；同一 valid time 的不同 init 不去重、不平均。
3. 均值/总体标准差 (`ddof=0`)；零方差列 scale=1 并记录。验证/测试只 transform，不 fit。
4. 保留物理单位原值和 scaler，测试正反变换。历史结构填充槽直接置零，不参与拟合。

加载检查会在内存篡改所有非训练值，再独立拟合；参数必须完全不变。不会写回任何源文件。

## 6. 主矩阵与训练设置：按已有设置记录，尚待执行锁

`3 sites × 2 horizons × 2 backbones × 3 pathways × 3 seeds = 108`。
骨干为 PatchTST（WSPR 历史骨干）和 iTransformer；路径为 History、gradient-repaired Direct、Residual。
源码只允许匹配既有冻结哈希；本地缺失的模型文件可以定位冻结 snapshot，但不能随便换成新模型。

沿用 d_model=128、d_ff=256、heads=8、e_layers=2、dropout=0.05、batch=32、Adam、LR=0.001、
MSE、type1 调度、最多 20 epochs、patience=5、CUDA AMP，seeds=2024/2025/2026。
其余模型所需固定值：factor=1、embed=timeF、activation=gelu；PatchTST 内建 patch_len=16、stride=8。
residual_l1_weight=0、physics_loss_weight=0、wspr_ablation=none，不改 gate 公式。
原 gate 依据步数 `H<=24`：本实验 4 h、24 h 均使用短时分支，不能套用旧 PVOD 96 步长时分支。

训练随机打乱、保留全部样本；验证/测试不打乱、不丢尾批。验证损失按所有目标元素加权汇总，
选最小 validation MSE checkpoint，同分保留更早 epoch。测试不进入每轮训练/早停。
这些明确规则必须在隔离的训练入口落实；不能直接调用通用 loader 或把原函数未检查地套上去。

原规划的 12-fit execution check：2107、两个 horizon、两个骨干、三条路径、seed2024。
它本身是训练，必须另获授权。若使用完全同一冻结配置跑完，可作为 108 行中的 12 行保留，
不能重复计数或挑选更好的一次；若只是截短 epoch 的工程试验，必须隔离且不进入主结果。
失败、重试及修复原因全部保留。不得按先行结果调参或变更站点、时长、路径。

## 7. 评价规则：先记录，后实现并验收

主指标：standardized MSE；必须同时报告 standardized MAE。辅助：RMSE、R²，
以及可靠逆变换的 MAE/RMSE (kW)。R² 分母为零时报告未定义，不补零。
不报告 MAPE（夜间和零值）；未核实统一 AC 额定容量前不把任意分母称作 capacity-normalized nRMSE/nMAE。
主评分不额外截断预测；“训练目标截零”不等于允许对所有预测做结果依赖的后处理。

保留逐 origin/lead 的所有种子预测；完整 test all-hours 是主分析，不挑白天、有利季节或站点。
同站点/时长先对每个种子独立算指标，再报告三种子均值及样本 SD (`ddof=1`)；不是先集成预测再算误差。
每时长分别等权汇总站点，报告三个站点的配对效应和 observed range；不把 3 seeds 或重叠窗口当作独立站点。
Residual–History、Direct–History、Residual–Direct 均报告，差值负号代表前者更好。
相对改善 `(reference-candidate)/reference` 分母为零时不定义；站点比值的均值与均值之比明确区分。

预设时间依赖描述区间：站内按 origin UTC 日期形成完整 2022 日历，空日保留为空，
7 天 circular moving blocks、10,000 paired draws、seed20260927；14 天作为固定敏感性。
同次抽样对所有路径、骨干、种子保持日期索引一致；保留每个 origin 的完整 lead 向量，
按抽中预测元素总数加权算误差，再 seed-first 汇总。区间为站内条件性 95% percentile 区间，
不是三站点总体推断、不增加 p 值/显著性星号，也不是多重性控制后的确证检验。
以上分析代码及合成验证尚待实施；实现前不称为统计验收完成。

不训练的参照建议：昨日同一 UTC 小时 seasonal persistence、train-only 月份×小时功率 climatology
（不足时按 hour 再全训练均值回退），每站点/时长两个控制，共 12 个评价单元。
此处不把普通昨日 persistence 叫作 smart/clear-sky persistence；早期可行性报告的 smart persistence
尚无冻结清空模型/太阳几何实现，正式控制方案仍需在最终执行协议中明确。

## 8. 训练前未完成门槛

1. 服务器原环境的完整模型依赖/导入、两种 horizon 的无训练 CPU/CUDA 前向、输入隔离及输出有限性。
2. 隔离训练入口、baseline/分析脚本及单元测试；全部设置展开，不能依赖未记录默认值。
3. 最终 execution lock 绑定数据、scaler、模型依赖、训练/分析代码、矩阵和本协议哈希；作者审核。
4. 明确批准 12 次执行检查，再决定启动/续跑剩余主矩阵。准备快照本身不授权训练。

任何机器准备通过只证明其明确范围；结果好坏未知，不承诺独立验证必然支持 WSPR。
三个外部站点能提供新增数据集证据，但不能自动修复旧研究的所有事后性或证明普遍优越。
