# HRRR production point extraction progress

Date: 2026-09-21 (Asia/Shanghai). This is a data-engineering record, not a model result.

## Verified pilot

The frozen split still contains 17,635 site/horizon/split origins. Deduplicating
their required forecasts gives 4,255 initialization cycles, 101,440 cycle--lead
objects, and 710,080 GRIB field messages. The exact selected field ranges total
1,038,769,714,932 bytes (approximately 967.43 GiB); retries add transfer overhead.
There are 209,324 required site--cycle--lead records. The extractor also retains
the other two station points from each downloaded message, giving a potential
304,320 rows in the final three-station point table.

The deterministic pilot covers January, April, July and October in 2020, 2021
and 2022, rotates through the four initialization hours, and uses leads 1, 4, 12
and 24. Its independent audit passed:

- 48 cycle--lead objects and 336/336 field messages decoded;
- 1,008/1,008 site-field values passed numeric QC;
- no missing messages, decoding errors or failed point values;
- exact object ETags, byte ranges, lengths and message hashes recorded;
- 330 requests succeeded on the first attempt and six on the second attempt.

The reference decoder check separately passed all 56 original messages and
168 station-field values, with absolute value differences at most 1e-6. The
isolated server runtime is pygrib 2.1.5 with ecCodes C 2.32.1. The original pilot
core is frozen at SHA-256
`e12818c7cef3dd65297b3f1edbc0bcdd17cf435dd3d993355ab4e5143a6c11d5`.

## Transport diagnosis

The first pilot transferred 486,320,157 bytes in 1,682.50 seconds, or 0.276 MiB/s.
A naive extrapolation to all selected fields would be about 42 days and is not
an acceptable reliable completion estimate. CPU and memory usage were low.

Three official S3 address forms returned an identical 1,197,761-byte TMP message
with matching ETags and SHA-256, taking 2.31--2.92 seconds in a small test. Changing
the hostname alone did not show a material advantage.

Re-fetching the eight slowest pilot objects with `Connection: close` completed
56 field messages / 90,095,338 bytes in 48.97 seconds (1.75 MiB/s). All payload
hashes matched the pilot exactly. Repeated-object caching may contribute, so
this benchmark alone does not prove sustained full-run throughput.

The version-2 driver therefore preserves the original decoder and scientific
contract, changes only connection reuse, and records its own hash. It has a
separate output directory and imports the 336 pilot records byte-for-byte after
checking their ordered hashes, plan identity and decoder reference results.
A further 96 previously unprocessed cycle--lead objects completed the sustained
transport check: 672 new messages, 808,246,694 bytes, 335.35 seconds and 2.2985 MiB/s,
with no new request retries or decoding errors. Independent QA of the accumulated
1,008 messages / 3,024 point values found no numeric failures. Full-plan status
correctly remained `INCOMPLETE` because 709,072 messages had not yet been extracted.
The `sustained_execution.json` and `sustained_numeric_qc.json` snapshots preserve
this checkpoint. Linear extrapolation at this measured rate is about five days;
actual completion time depends on future network conditions and failures.

Full background extraction started at 2026-09-20 18:14:36 UTC (2026-09-21 02:14:36
Asia/Shanghai) on `xingyu@202.201.244.51`, supervisor PID 4165097. This records launch,
not completion. The live `progress.json`, `supervisor_status.json` and
`full_extraction.log` in the server's `hrrr_point_extraction_v2` directory are the
current status sources. Existing decoded records are skipped after integrity checks.

## Numeric and time contract

The selected fields are TMP (K), RH (%), UGRD and VGRD (m/s), PRES (Pa), TCDC (%)
and DSWRF (W/m2). All must be instantaneous forecasts with the expected field
identifier, height/level, initialization, forecast lead and valid time. No field
is deaccumulated. Broad physical bounds are frozen in the extraction plan;
failures are retained with reasons, never silently clipped or imputed.

The pilot U/V messages have `uvRelativeToGrid=1`: these are native grid-relative
components, not earth-relative eastward/northward components. The extracted
values retain that convention. Wind speed can be derived as sqrt(U^2+V^2);
earth-relative directions would require a documented rotation.

The nearest grid cell is validated against the earlier decoded reference, and
the nearest-cell calculation is repeated for each distinct grid definition.
Each record retains initialization and lead, including in the final CSV. These
forecasts must not be collapsed into a single valid-time series that mixes
forecast vintages. Initialization does not establish actual publication latency.

## Files and completion gate

- `hrrr_point_extraction_v1/`: original pilot, transport benchmarks and immutable source plan.
- `hrrr_point_extraction_v2/`: production journal, progress and transport-driver provenance.
- `extract_hrrr_points_v1.py`: frozen decoding and download core.
- `extract_hrrr_points_v2.py`: connection policy and verified pilot import.
- `audit_hrrr_extracted_points_v1.py`: independent message/point QC and final origin join.
- `run_hrrr_extraction_supervisor_v1.py`: detached extraction followed by final QA; no training command.

The server retains decoded points and provenance, rather than the approximately
1 TB of continental GRIB payloads. The extraction journal supports resuming;
fourteen field errors stop an invocation for diagnosis. A background supervisor
records failures and only declares completion after the independent full QA.

Full completion requires all 710,080 planned messages to be decoded, explicit
handling of any numeric failures, a final `hrrr_site_points.csv`, and the
admitted/excluded origin lists under the unchanged date boundaries. The small
pilot PASS must not be described as full three-year numeric QC.

No model training, hyperparameter search or manuscript edits were performed.
Before the 12-run model execution check, the power target convention, historical
NWP input contract and temporal-block statistical plan still need to be frozen.
