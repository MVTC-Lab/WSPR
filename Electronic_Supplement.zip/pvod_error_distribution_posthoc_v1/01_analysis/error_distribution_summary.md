# PVOD Error-Distribution Post-Hoc Summary

This report is descriptive and post hoc. It uses frozen predictions and performs no training or model selection.

## Integrity

- Frozen PVOD runs checked: 360.
- Maximum registry MSE discrepancy: 9.714e-17.
- Maximum metrics.npy MSE discrepancy: 0.000e+00.
- Maximum reconstructed-truth discrepancy: 1.190e-07.
- All within-family three-way truth comparisons matched exactly.

## Direct versus Residual task-level effects

Negative differences favor Residual-NWP. Values are means of station-level values after averaging seeds within station.

| Backbone | H | Subset | ΔMSE | ΔMAE | ΔP50 AE | ΔP95 AE | ΔP99 AE | Fraction lower AE |
|---|---:|---|---:|---:|---:|---:|---:|---:|
| WSPR_history_backbone | 16 | active_generation | -0.048999 | -0.022415 | -0.004126 | -0.118328 | -0.198061 | 0.511 |
| WSPR_history_backbone | 96 | active_generation | -0.016862 | +0.001751 | +0.012569 | -0.077499 | -0.083863 | 0.495 |
| iTransformer | 16 | active_generation | -0.022609 | -0.010042 | -0.001647 | -0.053515 | -0.105853 | 0.503 |
| iTransformer | 96 | active_generation | -0.036951 | -0.014524 | -0.005249 | -0.093971 | -0.096218 | 0.516 |
| WSPR_history_backbone | 16 | all | -0.019016 | +0.014955 | +0.058973 | -0.070716 | -0.161808 | 0.317 |
| WSPR_history_backbone | 96 | all | -0.004826 | +0.026355 | +0.060389 | -0.025151 | -0.105718 | 0.329 |
| iTransformer | 16 | all | -0.011180 | +0.013674 | +0.043974 | -0.039892 | -0.100218 | 0.322 |
| iTransformer | 96 | all | -0.016316 | +0.015746 | +0.055622 | -0.044728 | -0.121651 | 0.329 |

## Interpretation guardrail

- WSPR_history_backbone, H=16: both upper-tail improvement and worse typical/average absolute error.
- WSPR_history_backbone, H=96: worse typical/average absolute error without consistent upper-tail improvement.
- iTransformer, H=16: both upper-tail improvement and worse typical/average absolute error.
- iTransformer, H=96: both upper-tail improvement and worse typical/average absolute error.

## Active-generation sensitivity

- WSPR_history_backbone, H=16: direction changes for at least one metric; all ΔMSE=-0.019016, active ΔMSE=-0.048999; all ΔMAE=+0.014955, active ΔMAE=-0.022415.
- WSPR_history_backbone, H=96: same direction; all ΔMSE=-0.004826, active ΔMSE=-0.016862; all ΔMAE=+0.026355, active ΔMAE=+0.001751.
- iTransformer, H=16: direction changes for at least one metric; all ΔMSE=-0.011180, active ΔMSE=-0.022609; all ΔMAE=+0.013674, active ΔMAE=-0.010042.
- iTransformer, H=96: direction changes for at least one metric; all ΔMSE=-0.016316, active ΔMSE=-0.036951; all ΔMAE=+0.015746, active ΔMAE=-0.014524.

No inferential p-values are produced.
