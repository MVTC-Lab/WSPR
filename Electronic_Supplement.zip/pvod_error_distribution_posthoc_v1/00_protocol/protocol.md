# PVOD Error-Distribution Post-Hoc Protocol v1

- Protocol ID: `pvod_error_distribution_posthoc_v1`
- Lock date: 2026-09-13 (Asia/Shanghai)
- Classification: post-hoc descriptive/mechanistic analysis
- Training: none; only frozen `pred.npy`, `true.npy`, and `metrics.npy` artifacts are read
- Model selection: prohibited

## Scope

The analysis covers the WSPR history-backbone family and the iTransformer family. Within each family it includes controlled History-only, gradient-enabled Direct-NWP, and Residual-NWP/WSPR. PVOD horizons are H=16 (approximately 4 h) and H=96 (approximately 24 h), stations are 00--09, and seeds are 2024, 2025, and 2026.

## Integrity checks

For every station, horizon, and seed, all three methods within a backbone family must have identical truth-array shapes and values. Prediction shapes must equal truth shapes. Arrays must be finite. MSE and MAE recomputed from arrays must agree with both the run registry and `metrics.npy` within floating-point tolerance. The truth arrays must also agree with the test targets reconstructed from the frozen chronological split and training-only scaler. A failed integrity check excludes no run silently: the analysis stops with an error.

## Error quantities

For error `e = prediction - truth`, calculate squared error `SE=e^2`, absolute error `AE=|e|`, MSE, RMSE, MAE, P50/P75/P90/P95/P99 AE, and signed mean error. For matched Direct-versus-Residual pairs additionally calculate Residual-minus-Direct differences in these summaries, fractions with lower AE and SE under Residual, and descriptive quantiles of `delta_AE` and `delta_SE`.

## Aggregation

Each metric is calculated separately for each station and seed. The three seed-level metrics are averaged to obtain one station-level value. Summaries across the ten physical stations report mean, median, IQR, minimum, and maximum. Seeds are not treated as independent physical samples.

## Forecast-lead analysis

For Direct-NWP and Residual-NWP, lead-wise MAE, MSE, and RMSE are calculated for each station and seed, then aggregated seed to station to across stations. PVOD uses 15 minutes per forecast step.

## Active-generation sensitivity

For station `s`, define `tau_s = 0.01 * Q99(training OT_s)`, using only the chronological training partition of the frozen confirmatory CSV. A forecast point is active when its raw-scale true PV value exceeds `tau_s`. The mask is evaluation-only and does not affect model input or training. The term `daylight` is not used because astronomical daylight data are unavailable.

## Statistical treatment

No new null-hypothesis testing family is introduced. Effect sizes, paired station differences, descriptive distributions, and plots are primary. Where intervals are reported, ten physical stations are resampled with replacement for 10,000 draws using fixed seed 20260913; these intervals are explicitly descriptive and post hoc.

## Frozen inputs

- `papers/WSPR_AppliedEnergy/evidence/data/all_results.csv`
- `experiments/wspr_q1/history_only_confirmatory/02_analysis/all_results.csv`
- Remote run-level prediction directories referenced by those registries
- `/home/xingyu/xiangmu/Times/papers-with-code/datasets/PV/processed_research/confirmatory_splits/PVOD_pre80/`

## Interpretation guardrails

The analysis will not assume in advance that Residual-NWP reduces extreme errors. Findings may be upper-tail improvement, worse typical errors, both, neither, or site-dependent. Results remain post hoc and cannot be used to relabel the original comparisons as prospectively confirmatory.
