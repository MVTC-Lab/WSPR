"""Offline, read-only integrity and saved-scalar consistency checks (stdlib only)."""
from pathlib import Path, PurePosixPath
from collections import defaultdict
import csv, hashlib, json, math
ROOT=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p,delimiter=','):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter=delimiter))
def main():
    m=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
    entries=m['files']; names=[x['path'] for x in entries]
    assert len(names)==len(set(names)), 'Duplicate manifest paths'
    for item in entries:
        pure=PurePosixPath(item['path'])
        assert not pure.is_absolute() and '..' not in pure.parts and '\\' not in item['path']
        p=ROOT.joinpath(*pure.parts)
        assert p.is_file() and not p.is_symlink(), item['path']
        assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],item['path']
    actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    assert actual==set(names)|{'manifest.json','SHA256SUMS'}, 'Untracked/missing files'
    checksum={}
    for line in (ROOT/'SHA256SUMS').read_text(encoding='utf-8').splitlines():
        digest, name=line.split('  ',1);assert name not in checksum;checksum[name]=digest
    assert set(checksum)==actual-{'SHA256SUMS'}
    for name,digest in checksum.items():assert sha(ROOT/name)==digest,name
    index=rows(ROOT/'INDEX.tsv','\t')
    assert [r['section'] for r in index]==['S'+str(i) for i in range(1,31)]
    for r in index:
        for name in r['package_paths'].split(';'): assert (ROOT/name).exists(),name
    primary=rows(ROOT/'v6_frozen_coverage_audit_v1/primary_run_metrics.csv')
    key=lambda r:(r['dataset'],r['backbone'],r['pathway'],r['unit'],r['seq_len'],r['pred_len'],r['seed'])
    assert len(primary)==len({key(r) for r in primary})==468
    assert sum(r['dataset']=='PVOD' for r in primary)==360
    cells=defaultdict(list)
    for r in primary:cells[(r['backbone'],r['dataset'],r['pred_len'],r['pathway'],r['unit'])].append(r)
    tasks=defaultdict(list)
    for key_,rs in cells.items():
        assert len(rs)==3
        tasks[key_[:4]].append({k:sum(float(r[k]) for r in rs)/3 for k in ('mse','mae')})
    taskrows=rows(ROOT/'reporting_protocol_v1/primary_task_metrics.csv')
    assert len(taskrows)==24
    for r in taskrows:
        rs=tasks[(r['backbone'],r['dataset'],r['horizon'],r['pathway'])]
        assert len(rs)==int(r['units']) and 3*len(rs)==int(r['runs'])
        for metric in ('mse','mae'):
            value=sum(x[metric] for x in rs)/len(rs)
            assert math.isclose(value,float(r[metric]),rel_tol=1e-12,abs_tol=1e-12),(r,metric)
            assert format(value,'.4f')==r[metric+'_display']
    assert len(rows(ROOT/'reporting_protocol_v1/pvod_split_dates_counts.csv'))==20
    assert m['submission_ready'] is False and m['publication_status']=='local_preparation_only'
    print(json.dumps({'status':'PASS','files_hashed':len(entries),'checksummed_files':len(checksum),'primary_runs':468,'task_means_checked':24,'pvod_reporting_rows':20,'indexed_sections':30,'training_or_model_execution':False},indent=2))
if __name__=='__main__':main()
