# Protocol: PVOD suffix temporal-sensitivity evaluation

- Protocol ID: `pvod_suffix_temporal_sensitivity_v1`
- Lock date: 2026-09-19 (Asia/Shanghai)
- Status at creation: fixed before the current checkpoints are evaluated on the suffix
- Classification: post-hoc temporal-sensitivity analysis; not confirmatory validation
- Training: none

## Question and scientific boundary

This analysis asks whether the already trained PVOD History-only, Direct-NWP,
and Residual-NWP checkpoints retain their reported error directions after the
end of the first 80% of each station series. The final 20% was used in older
full-series experiments before the current prefix was constructed. It is
therefore not untouched, independent, or prospectively reserved. No result from
this analysis may be described as external confirmation, prospective
validation, or evidence that eliminates split-selection uncertainty.

## Frozen matrix

The analysis includes every current PVOD checkpoint in the controlled
three-path comparison:

- units: `station00` through `station09`;
- target horizons: 16 and 96 steps (approximately 4 and 24 hours);
- seeds: 2024, 2025, and 2026;
- backbones: WSPR history backbone and iTransformer;
- pathways: History-only, Direct-NWP, and Residual-NWP;
- expected evaluations: 10 x 2 x 3 x 2 x 3 = 360.

No checkpoint or station may be removed because of its result. Compatibility
or runtime failures remain in the failure ledger and reduce declared coverage.

## Data, scaler, and window construction

For a full station series of length `N`, define `M=floor(0.8*N)` exactly as in
the recovered prefix builder and `T=floor(0.7*M)` exactly as in the training
loader used for the prefix checkpoints.

1. Reproduce the original builder's `read_csv -> iloc[:M] -> to_csv -> read_csv`
   operation in memory and require exact parsed table equality with the prefix
   file, including column order and values. Record raw parsed differences before
   this round-trip; do not accept a numeric-tolerance substitute for equality.
2. Recreate each checkpoint's `StandardScaler` from rows `[0,T)` of the actual
   prefix file only. Do not
   refit or update the scaler on later rows.
3. The first suffix target begins at row `M`. Each input window may use the
   preceding `seq_len` rows; every target window must lie wholly in `[M,N)`.
4. Preserve the original channel order, known-future dimensions, target
   masking, timestamp features, model parameters, and checkpoint weights.
5. Do not tune, select, calibrate, or train on suffix outcomes.

Before a suffix result is accepted, the same evaluation implementation must
replay that run's saved prefix-test `pred.npy` and `true.npy` within fixed
numeric tolerances (prediction maximum absolute difference <= 2e-5, truth
maximum absolute difference <= 1e-7).

## Fixed outputs and metrics

For every run, retain standardized-scale MSE, MAE, RMSE, and R2, eligible window
and point counts, prefix replay differences, checkpoint/data/scaler hashes, and
the first/last suffix target timestamps. Store the deterministic suffix
prediction and truth arrays in a compressed run artifact.

The active-generation thresholds are fixed at 0.5%, 1%, 2%, and 5% of the
station-specific 99th percentile of raw target power in rows `[0,T)`. Masks are
evaluation-only and use raw true target power. Report each threshold's MSE, MAE,
RMSE, point count, and fraction. They are not astronomical-daylight masks.

Aggregate seeds first within each `(backbone, pathway, station, horizon)` cell.
Report all station effects and task means. Direct-versus-Residual and each
NWP pathway-versus-History directions are descriptive; no new significance
family is introduced. All reversals, null effects, and adverse outcomes remain.

## Stop and integrity conditions

Preparation or evaluation stops on any model-source hash drift, source-registry
cardinality mismatch, missing checkpoint, prefix/full-file mismatch, unsafe
future-target copy, prefix replay failure, nonfinite output, or duplicate run ID.
The new evidence is additive and must not overwrite the frozen 468-run primary
registry or any existing prediction/checkpoint directory.

## Pre-execution implementation correction (2026-09-19)

The initial preparation stopped before locking or evaluating any checkpoint:
station00 had one wind-direction cosine cell differing by 2.465190328815662e-32
between direct parsing of the full file and parsing the prefix export. Replaying
the documented original builder's CSV round-trip made all cells exactly equal.
The identity check now reproduces that actual construction rather than assuming
CSV serialization is bit-preserving. No tolerance was widened, and predictive
outcomes were not inspected. Scaler fitting uses the actual prefix file.
