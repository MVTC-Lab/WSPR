# Locked protocol: targeted residual-constraint decomposition

## Purpose

This is a targeted post-hoc mechanism analysis requested after review of the
frozen WSPR v8.3 evidence. It asks which factor of the bounded residual
construction contributes under the existing PVOD protocol. It is not a search
space, hyperparameter tuning exercise, confirmatory replication, or basis for
selecting a new production model.

## Invariants

- Official `models/TimeMixer_7.py` and `run_TimeMixer.py` remain unchanged.
- WSPR version remains v8.3; no v8.4 is created.
- Frozen evidence and current manuscripts remain read-only.
- Dataset: PVOD `confirmatory_pre80`, stations 00--09.
- Tasks: `96->16` and `96->96`.
- Seeds: 2024, 2025, and 2026.
- Architecture, optimizer, epochs, early stopping, scaler, windows, target,
  known-future channels, and evaluation metrics match the existing protocol.
- The 60 Full WSPR references are loaded from the frozen source-of-truth CSV;
  Full WSPR is not retrained.

## New runs

Three interventions x ten stations x two horizons x three seeds = 180 runs.
The exact rows are materialized in `experiment_matrix.csv` before launch.

## Primary analysis

For each station, the three seeds are averaged first. Each intervention is then
paired with frozen Full WSPR over ten stations separately at each horizon. The
primary endpoint is MSE. The six two-sided paired Wilcoxon tests form one new
Holm family. Station-level bootstrap confidence intervals use 10,000 resamples.
MAE and R2 are descriptive secondary outputs.

No result from this experiment will be inserted retrospectively into an earlier
Holm family. Non-significance is not interpreted as equivalence. Because factor
interactions can remain, any attribution is limited to this locked protocol.
