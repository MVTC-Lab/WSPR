# Residual-constraint decomposition implementation report

Status: **PASS**

## Full-mode equivalence

| Horizon | State init | Final | History | Gated residual | Gate |
|---:|---:|---:|---:|---:|---:|
| 16 | 0 | 0 | 0 | 0 | 0 |
| 96 | 0 | 0 | 0 | 0 | 0 |

## Intervention formula and gradient smoke tests

| Mode | Formula max abs diff | Finite output | Finite gradients | Status |
|---|---:|---|---|---|
| full | 0 | True | True | PASS |
| no_history_span | 0 | True | True | PASS |
| no_max_scale | 0 | True | True | PASS |
| no_tanh_bound | 0 | True | True | PASS |
