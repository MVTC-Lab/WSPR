# Exact intervention definitions

Let `l` denote the unconstrained output of the existing residual head,
`s_hist` the existing history-derived target span, and `m` the existing learned
maximum-scale factor. Full WSPR v8.3 uses:

`delta_raw = m * s_hist * tanh(l)`.

Only the displayed factor changes in each intervention:

- **NoTanh** (`no_tanh_bound`): `delta_raw = m * s_hist * l`.
- **NoHistorySpan** (`no_history_span`): `delta_raw = m * tanh(l)`.
- **NoMaxScale** (`no_max_scale`): `delta_raw = s_hist * tanh(l)`.

The adapter inputs, shared representation, residual head, adaptive gate,
gate floor, horizon prior, NWP availability mask, detached base conditioning,
loss, training schedule, and data protocol are otherwise unchanged.

These are single-factor interventions on a multiplicative construction, not
claims that the three factors act independently. `NoTanh` is intentionally
unbounded and may be less stable; failed or non-finite runs must be reported,
not silently replaced.
