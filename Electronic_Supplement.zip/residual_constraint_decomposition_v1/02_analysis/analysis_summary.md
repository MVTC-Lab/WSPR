# WSPR v8.3 residual-constraint decomposition

Status: targeted post-hoc mechanism analysis; not model selection and not a new WSPR version.
Seeds were averaged within station; the independent unit is the station (n=10).
The new Holm family contains exactly six two-sided paired MSE comparisons.
Positive relative MSE change means the intervention is worse than frozen Full WSPR v8.3.
W/T/L is reported from the intervention's perspective.

| Variant | MSE 96->16 | Delta (%) | W/T/L | Holm p | MSE 96->96 | Delta (%) | W/T/L | Holm p |
|---|---:|---:|:---:|---:|---:|---:|:---:|---:|
| Full WSPR v8.3 | 0.135603 | +0.00 | reference | -- | 0.207691 | +0.00 | reference | -- |
| NoTanh | 0.136785 | +0.87 | 5/0/5 | 0.9844 | 0.186069 | -10.41 | 10/0/0 | 0.0117 |
| NoHistorySpan | 0.120870 | -10.86 | 9/0/1 | 0.0195 | 0.202496 | -2.50 | 6/0/4 | 0.9668 |
| NoMaxScale | 0.135834 | +0.17 | 3/0/7 | 0.9844 | 0.184913 | -10.97 | 9/0/1 | 0.0195 |

Interpretation guardrail: a significant positive difference supports an incremental contribution of the removed factor under this locked protocol. A non-significant result is inconclusive, not evidence of equivalence. Interactions among the three factors may remain.
