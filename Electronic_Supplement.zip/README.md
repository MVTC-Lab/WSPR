# WSPR v18 — Electronic numerical supplement (2026-11-10)

This locally prepared numerical bundle accompanies the updated manuscript and the
27-page printed Supplement (S1–S30). This preparation does not submit or publish
the numerical bundle or grant a new redistribution license.

## Exact document identity

- Main manuscript SHA256: `64550d6c23cf3273595235f2f4ca1a288ec7a32463907d2474857fcc6ff6b6ef` (24 pages).
- Printed Supplement SHA256: `567ad927cac3772cea4913cf25b1a78717c82b7f2a4bfe1984884c9eeab9a12e` (27 pages, S1–S30).

The two PDFs are delivered separately from this directory. `INDEX.tsv` maps every
printed section to the available numerical material and states scope limits.
`manifest.json` binds every included file and its historical source identity;
`SHA256SUMS` also covers that manifest. All navigation uses package-relative paths.
Absolute historical paths inside inherited records identify original inputs only;
they are not portable access instructions or claims that those inputs are bundled.

## Evidence classes

- `v6_frozen_coverage_audit_v1/primary_run_metrics.csv`: 468 primary records,
  comprising 360 PVOD and 108 corrected GEFCom records. Superseded GEFCom is not pooled.
- `reporting_protocol_v1/primary_task_metrics.csv`: 24 task/pathway means, with
  full-precision MSE/MAE and displayed values. `pvod_split_dates_counts.csv` has
  20 site-by-horizon boundary/count records accompanying the current main text.
- `residual_constraint_decomposition_v1/`: the completed 180-fit post-hoc
  component-removal study plus reused full-model reference values. Removal variants
  that outperform full WSPR are retained. This is distinct from unimplemented future
  unconstrained-Direct training proposals, which are not included.
- `pvod_error_distribution_posthoc_v1/`, `pvod_suffix_temporal_sensitivity/`,
  `pvod_climatology_control_v1/`, gate/permutation files and corrected-GEFCom
  diagnostics retain all included outcome directions, seeds and masks.
- `pvdaq_hrrr_independent_v1/`: separate 108-fit, three-site study, including
  unfavorable Residual-versus-Direct comparisons and conditional intervals.
- `S29_Direct_Output_Range_Diagnostic/`: frozen-array output-geometry evidence;
  its oracle is a geometric lower bound, not an unconstrained trained predictor.
- `S30_PVDAQ_Two_Site_Sensitivity/`: post-hoc 72-run scalar subset analysis;
  it does not replace the primary three-site study or resolve negative-power semantics.
- `displayed_supplement_tables/`: exact current TeX tables. Their numeric precision
  is the published display precision; missing full-precision numbers were not invented.
- `pvod_deterministic_baselines/`: existing PVOD prefix rows only; original numeric
  strings are unchanged. Old full-series PVOD/superseded GEFCom rows are not current evidence.

Legacy labels `WSPR history backbone`, `WSPR-history`, and `WSPR` mean PatchTST;
the pathway field specifies History-only, Direct-NWP or Residual-NWP. PVOD steps
are 15 minutes; GEFCom and independent PVDAQ steps are one hour. Aggregation is
seed-first within a physical unit and then equal-unit, unless a particular diagnostic
explicitly specifies otherwise. Origin/lead entries can overlap in valid time.

## Access, reproduction and inherited records

The package is scalar/protocol evidence, not a full dataset or model-code release.
Native complete datasets, checkpoint weights, trained prediction/truth arrays,
deterministic-control prediction arrays and bootstrap arrays are not included.
The derived row-level `preflight_audits/gefcom_negative_increment_audit.csv` is
retained unchanged because printed S3 explicitly refers to it; it contains selected
measurement information, not the complete native predictor archive. Provider terms
continue to apply. Original provider contact metadata, internal code inventories,
duplicate packaging history and unimplemented training proposals are omitted.

Included original analysis scripts document scoring and require their recorded
external project/data dependencies. They are not a promise of one-command training
or a claim that model inference has been repeated here. No training, model inference,
raw-array rescoring, selection of a new checkpoint, or new significance test was run
for this package. `LEGACY_README.md` files are unchanged historical explanations;
their original full-package inventory may exceed this curated selection. The current
README, INDEX and manifest define what is actually bundled.

The model code is publicly available at https://github.com/MVTC-Lab/WSPR.
This local preparation does not change the manuscript's AI declaration. Data/provider
redistribution conditions and final author approval remain review-before-upload
items; `submission_ready` is false.

## Offline checks

From any working directory, run:

```text
python -B /path/to/electronic_supplement/verify_package.py
```

This standard-library-only, offline/read-only check verifies safe paths, full file
coverage, sizes and SHA256, S1–S30 index targets, 468 unique primary run identities,
24 task means from saved scalar metrics, and 20 PVOD reporting rows. It does not
certify scientific validity, permissions, reproducibility, or submission approval.

## Distribution with the project repository

This numerical archive is distributed separately from the supplementary PDF through the WSPR project repository. References to `electronic_supplement/` in the paper identify this extracted archive root. The contents are selected analysis/protocol evidence, not complete original datasets, weights or prediction arrays. Preparation-status fields record packaging provenance and do not indicate journal acceptance.
