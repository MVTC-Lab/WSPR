# Corrected GEFCom authoritative CSVs

Exact read-only copies of the three authoritative source CSVs named in Supplement S4/S8, recovered from the corrected server experiment directory on 2026-11-06. Source paths, sizes and SHA256 are in source_manifest.json. The task and diagnostic hashes exactly match the hashes printed in the unchanged v17 Supplement. These are existing outcomes, not new experiments. Historical classifications remain unchanged; do not combine superseded GEFCom data with this corrected evidence.
