# v6 frozen coverage audit v1

Date: 2026-09-19. Post-hoc descriptive audit; no training or model selection.

1. Inspect all prepared test windows for each of 10 PVOD sites and 3 corrected
   GEFCom regions at both horizons. Calculate the actual standardized NWP
   presence rule (mean absolute future NWP > 1e-6), with counts of windows whose
   first target has raw generation above/below 1% of training Q99. This is a
   generation proxy, not astronomical daylight.
2. Recompute the 108 corrected GEFCom frozen runs on full, active-generation
   (raw truth > 1% training Q99), positive deaccumulated VAR169, and VAR169 above
   its positive training 75th percentile. Report MSE/MAE and eligible counts.
   Inverse-target identity must agree with the saved standardized truth at 1e-7.
   All three pathways share identical target/mask arrays. Regions remain n=3.
3. Report per-unit seed means and sample SD for all 468 primary records.
4. On one fixed station/region and seed 2024 per dataset/backbone/horizon/pathway
   (24 settings), measure full forward inference at batch size 32, AMP, 20 warmup
   and 100 synchronized iterations. Report median/p95 batch latency and peak
   allocated CUDA memory. GPU identity and environment are recorded. This is a
   single-hardware microbenchmark excluding I/O, not operational deployment cost.

The script and source manifests are hashed in the audit outputs. All metrics
are standardized unless explicitly labelled otherwise. All outputs are additive
and retained in this directory; original registries and prediction arrays are
read-only. The full suffix and climatology experiments have separate protocols.
