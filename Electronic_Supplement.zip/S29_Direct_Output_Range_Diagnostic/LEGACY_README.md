# S29 — Direct-NWP output-range diagnostic

Status: **fresh frozen-array verification PASS, 2026-11-06**. This is a post hoc, CPU-only diagnostic. It does not train a model, run a model forward pass, use a GPU, change predictions, or establish a causal decomposition of Direct–Residual differences.

## Scope and inputs

The audit reread all **312 frozen NWP records**: 240 PVOD and 72 corrected GEFCom, comprising 156 Direct-NWP and 156 Residual-NWP records. There are 26 unique site/region–horizon combinations, two backbones and three seeds. History-only runs are outside this diagnostic; 312 is not a replacement for the paper's 468-run primary matrix.

For every record the fresh audit checked processed-data, checkpoint, prediction and truth SHA256 against the frozen manifest. It reconstructed standardized truth with the original `Dataset_Custom` and train-fitted `StandardScaler`, checked bitwise equality to every saved `true.npy`, and checked that raw OT transformed with that same scaler reproduces the loader truth. Both Direct heads' imported `HistoryStats.target_bounds` implementations were checked against the actual historical implementation. No weights were loaded and no new prediction was generated.

All retained-NWP windows had presence `m = 1`. The maximum floating-point support deviation among Direct predictions was `4.76837158203125e-07` standardized units.

## Interval, tolerance and scoring

The interval uses only the target channel of the historical input window, with exactly the model's torch float32 operations:

1. `lower` is the mean of the lowest `max(1,L//4)` historical targets.
2. `high` is the mean of the highest `max(1,L//8)` historical targets.
3. `upper = max(high + 0.25 * std_population + 0.05, lower + 0.35)`.
4. `span = max(upper - lower, 0.10)` and the effective upper endpoint is `lower + span`.

The interval's lower endpoint is distinct from the historical backbone forecast denoted by `b_hat` in the model diagram. Future targets are used only for scoring, never for constructing the interval.

`E_bound = mean((y - clip(y, lower, lower + span))**2)` uses exact closed-interval projection in float64, with no tolerance relaxation. Actual prediction MSE/MAE are unchanged. A tolerance of **1e-6 standardized power units** is used only for the descriptive inside/outside classification, avoiding spurious strict below-bound classifications caused by float32 averaging of repeated night baselines. Strict results and the grid `0, 1e-7, 1e-6, 1e-5, 1e-4` are retained. Presence uses the actual `mean(abs(retained standardized NWP)) > 1e-6` window criterion.

All principal errors are on the original **training-standardized target scale**. Overall seed/subset rows also retain raw-scale MSE/MAE obtained with the same frozen target scale; this is an affine rescaling, not a replacement target.

## Aggregation and time units

Compute each seed's errors first; average three seeds within a site/region–backbone–pathway–horizon cell; then average physical sites/regions equally. The oracle/Direct MSE percentage is the ratio of these task means, not an average of per-unit ratios.

`pred_len` is the number of forecast steps. **PVOD has 0.25 h steps**, so 16 and 96 steps are 4 h and 24 h. **GEFCom has 1 h steps**, so 24 and 96 steps are 24 h and 96 h. `sample_interval_hours` and `durationHours` make the distinction explicit.

Geometry is seed/backbone-invariant and is computed only once for each of the 26 unique unit-tasks. `output_range_by_unit.csv` repeats this geometry alongside each backbone's Direct errors (52 rows); the task table has 8 rows, not 8 independently observed geometries. Do not sum replicated geometry counts across backbones or seeds.

`outside_fraction` / `outside_percent` are **equal-unit means of fractions**. Summed `n_outside` divided by summed `n_available_points` is instead a point-pooled fraction; this different quantity is separately named `outside_fraction_pooled_points`. It need not equal the paper percentage when unit sample sizes differ. Forecast-window lead-target elements overlap and are not independent statistical observations. No new significance test is produced.

Conditional errors use the same seed-first/equal-unit rule. Empty subsets have zero point counts and undefined (`NaN` / empty CSV) errors, never fabricated zero errors. `units_with_points` records which units contribute to a conditional task mean.

## Recomputed publication values

| Dataset | Steps | Hours | Outside (%) | Oracle MSE | Oracle / Direct MSE (%), PatchTST | Oracle / Direct MSE (%), iTransformer |
|---|---:|---:|---:|---:|---:|---:|
| PVOD | 16 | 4 | 4.989767 | 0.046302 | 29.946017 | 29.444185 |
| PVOD | 96 | 24 | 6.226492 | 0.080587 | 37.920554 | 36.721654 |
| GEFCom | 24 | 24 | 3.349825 | 0.009218 | 9.895420 | 9.887739 |
| GEFCom | 96 | 96 | 2.567812 | 0.003597 | 4.192761 | 4.058019 |

The paper's 4.99%, 6.23%, 3.35%, 2.57% and PVOD 29.44%–37.92% reproduce at their stated rounding. All 128 existing-column comparisons against the original `tolerance_v2` outputs passed; the principal existing numerical CSVs remain byte-identical where no new provenance/count columns were added.

The oracle is a geometric lower bound on a constrained output support. It is not a deployable predictor, a retrained unconstrained Direct result, an achievable error reduction, or proof that the entire Direct–Residual difference arises from this constraint. An isolated unconstrained Direct training control is still required to answer that experimental question.

## Files

- `output_range_by_unit.csv`: per-unit/backbone seed-averaged Direct errors, exact interval geometry, counts, scaler values, outside fractions and lower-bound/Direct ratio.
- `output_range_by_task.csv`: equal-unit task results, counts, explicitly separate point-pooled outside fraction and forecast duration.
- `conditional_errors.csv`: 720 per-unit and task rows for both paths and inside/outside/below/above/unavailable subsets.
- `seed_metrics.csv`: 55,152 fresh seed/subset/lead error rows, retaining adverse and empty subsets.
- `checked_source_manifest.csv`: 312 verified source records with paths, hashes and truth/scaler checks.
- `direct_support_checks.csv`: 156 Direct support and oracle checks.
- `unit_bounds_geometry.csv`, `task_bounds_geometry.csv`, `unit_lead_bounds_geometry.csv`, `task_lead_bounds_geometry.csv`: geometry and lead-level detail. Reconstructed lower/upper/truth/presence array hashes are recorded without redistributing the arrays.
- `unit_seed_averaged_metrics.csv`, `task_equal_unit_metrics.csv`, `task_summary.csv`: exact aggregation intermediates.
- `task_boundary_tolerance_sensitivity.csv`: strict and tolerance-grid diagnostics.
- `reference_v2_comparison.csv`, `publication_value_checks.csv`: fresh-vs-prior and paper-value verification.
- `input_frozen_source_manifest.csv`, `input_frozen_lock.json`: unchanged frozen input manifest/lock copies; paths point to external artifacts, not bundled data.
- `protocol.json`, `summary.json`, `generator_provenance.json`: definitions, fresh execution checks, code/source identity and output hashes.
- `analyze_output_range.py`: complete fresh-array analysis script.
- `SHA256SUMS`: every file in S29 except the checksum list itself. `summary.json` separately hashes generated CSV outputs; the later-added frozen input manifest is covered by `SHA256SUMS`.

## Reproduction and dependencies

**This S29 directory is an auditable numerical/protocol bundle, not a self-contained raw-data/checkpoint release.** It does not include full `pred.npy` / `true.npy` arrays, station CSVs, checkpoint weights or the project source tree. The input manifest names them and their expected hashes; access must follow the original project's data/reviewer-access conditions.

Required external inputs are the locked project code (`models/`, `data_provider/`, supporting `scripts/`), the frozen manifest/lock, processed datasets, and every listed checkpoint and prediction directory. The helper import supplies the original dataset construction and SHA reader; no inference function is called. Versions from the fresh execution are recorded in `protocol.json`.

Example on the original server, choosing a **new, empty output directory**:

```bash
env CUDA_VISIBLE_DEVICES='' /home/xingyu/miniconda3/envs/xy-3.8/bin/python -B -u \
  /path/to/S29_Direct_Output_Range_Diagnostic/analyze_output_range.py \
  --project-root /home/xingyu/xiangmu/Times/papers-with-code/Time-Series-Library-main \
  --output-dir /path/to/new_S29_reanalysis \
  --reference-dir /home/xingyu/xiangmu/Times/papers-with-code/Time-Series-Library-main/experiments/wspr_q1/direct_bound_diagnostic_20261106/tolerance_v2
```

The script refuses to overwrite an existing completed analysis. It checks original frozen hashes and stops on drift or missing input. Existing source paths may need a provenance-preserving root relocation when run elsewhere; do not silently alter expected hashes. The original strict analysis and v2 outputs remain untouched. No new training is authorized by this bundle.
