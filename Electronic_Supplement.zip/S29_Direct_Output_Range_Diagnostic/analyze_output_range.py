"""Post-hoc frozen Direct support audit. CPU only; no training/inference/data edits.

Bounds depend only on the standardized historical target window. Test outcomes
are used only to score violations, the support-oracle lower bound and errors.
"""
from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import sys
from pathlib import Path

parser = argparse.ArgumentParser(description="S29 read-only frozen-array output-range audit; no training or model forward.")
parser.add_argument('--project-root', type=Path, required=True)
parser.add_argument('--output-dir', type=Path, required=True)
parser.add_argument('--reference-dir', type=Path, default=None)
ARGS = parser.parse_args()
ROOT = ARGS.project_root.resolve()
sys.path.insert(0, str(ROOT))
import numpy as np
import pandas as pd
import torch

from scripts.wspr_q1.run_frozen_nwp_gate_diagnostics_v1 import dataset, sha
from models.TimeMixer_7_v8_3_final import HistoryStats

OUT = ARGS.output_dir.resolve()
PROTO = ROOT / 'experiments/wspr_q1/frozen_nwp_gate_diagnostics_v1/00_protocol'


def score(pred, true, mask):
    n = int(mask.sum())
    if not n:
        return dict(n_points=0, mse=np.nan, mae=np.nan)
    err = pred[mask].astype(np.float64) - true[mask].astype(np.float64)
    return dict(n_points=n, mse=float(np.mean(err * err)), mae=float(np.mean(np.abs(err))))


def main():
    torch.set_num_threads(2)
    OUT.mkdir(parents=True, exist_ok=True)
    if (OUT / 'summary.json').exists():
        raise RuntimeError('Completed output exists; refusing overwrite')
    lock = json.loads((PROTO / 'lock.json').read_text())
    manifest_path = PROTO / 'source_manifest.csv'
    assert sha(manifest_path) == lock['source_manifest_sha256']
    assert sha(ROOT / 'data_provider/data_loader.py') == lock['data_loader_sha256']
    for name, expected in lock['models'].items():
        assert sha(ROOT / 'models' / (name + '.py')) == expected, name
    records = pd.read_csv(manifest_path)
    assert len(records) == 312 and records.run_id.nunique() == 312
    assert set(records.pathway) == {'Direct-NWP', 'Residual-NWP'}
    source_rows, metric_rows, geometry_rows, lead_rows, validation_rows = [], [], [], [], []
    digest_cache = {}

    def checked_hash(path, expected):
        key = str(path)
        if key not in digest_cache:
            digest_cache[key] = sha(path)
        assert digest_cache[key] == expected, ('Source hash mismatch', key)
        return digest_cache[key]

    # Check the boundary implementation actually imported by BOTH Direct heads.
    import importlib
    direct_sources = {}
    for name in sorted(records.loc[records.pathway == 'Direct-NWP', 'model'].unique()):
        cls = importlib.import_module('models.' + name).HistoryStats
        assert inspect.getsource(cls.target_bounds) == inspect.getsource(HistoryStats.target_bounds)
        direct_sources[name] = sha(inspect.getfile(cls))
    (OUT / 'protocol.json').write_text(json.dumps({
        'declared_utc': pd.Timestamp.now(tz='UTC').isoformat(),
        'purpose': 'Post-hoc diagnostic of frozen bounded Direct output support; not a causal isolation test.',
        'training': False, 'model_forward': False, 'gpu': False,
        'bounds': 'HistoryStats.target_bounds(x_hist); upper_eff=lower+max(upper-lower,0.10).',
        'presence': 'abs(standardized retained NWP).mean over horizon and channels > 1e-6.',
        'boundary_tolerance': 'Primary inside/outside classification uses 1e-6 standardized-power units to avoid float32 historical-mean roundoff at repeated night baselines. Strict fractions and a tolerance grid are also reported. The exact-support oracle is never relaxed.',
        'oracle': 'mean squared distance of test outcome to closed Direct support, among m=1 points.',
        'aggregations': 'Compute errors per frozen seed; average seeds within unit-task; average units equally within task.',
        'subsets': ['available_all', 'inside', 'outside', 'below', 'above', 'unavailable'],
        'units': 'Primary errors are training-standardized power. Raw power errors additionally supplied at seed level.',
        'historical_target_bounds_sha256': direct_sources,
        'script_sha256': sha(__file__), 'source_manifest_sha256': sha(manifest_path),
        'data_loader_sha256': sha(ROOT / 'data_provider/data_loader.py'),
        'frozen_lock_sha256': sha(PROTO/'lock.json'),
        'external_project_root': str(ROOT),
        'external_dependency_notice': 'Full project code, processed source datasets, checkpoints, pred.npy and true.npy are external inputs, not embedded in S29.',
        'sample_interval_hours': {'PVOD': 0.25, 'GEFCom': 1.0},
        'execution_environment': {'numpy': np.__version__, 'pandas': pd.__version__, 'torch': torch.__version__, 'python': sys.version},
    }, indent=2), encoding='utf-8')

    for task_index, (key, group) in enumerate(records.groupby(['dataset', 'unit', 'seq_len', 'pred_len'], sort=True), 1):
        r0 = next(group.itertuples(index=False))
        assert group.groupby(['backbone', 'pathway']).seed.nunique().eq(3).all()
        ds = dataset(r0, 'test')
        H, L, K = int(r0.pred_len), int(r0.seq_len), int(r0.known_dim)
        n = len(ds)
        xvalues = ds.data_x.astype(np.float32)
        yvalues = ds.data_y.astype(np.float32)
        ix = np.arange(n)[:, None] + L + np.arange(H)[None, :]
        true = yvalues[ix, -1:]
        lower = np.empty((n, 1, 1), np.float32)
        upper = np.empty_like(lower)
        # Exact torch float32 operator and full C channels avoid surrogate bounds.
        for start in range(0, n, 512):
            ids = np.arange(start, min(start + 512, n))[:, None] + np.arange(L)[None, :]
            with torch.no_grad():
                lo, hi = HistoryStats.target_bounds(torch.from_numpy(xvalues[ids]))
                lower[start:start+len(ids)] = lo.numpy()
                upper[start:start+len(ids)] = (lo + (hi - lo).clamp_min(.10)).numpy()
        assert np.isfinite(lower).all() and np.isfinite(upper).all()
        assert (upper > lower).all()
        present = np.array([np.abs(yvalues[j+L:j+L+H, :K]).mean() > 1e-6 for j in range(n)])
        av = np.broadcast_to(present[:, None, None], true.shape)
        strict_below, strict_above = av & (true < lower), av & (true > upper)
        below = av & (true.astype(float) < lower.astype(float)-1e-6)
        above = av & (true.astype(float) > upper.astype(float)+1e-6)
        outside = below | above
        inside = av & ~outside
        masks = {'available_all': av, 'inside': inside, 'outside': outside,
                 'below': below, 'above': above, 'unavailable': ~av}
        assert np.array_equal(inside | outside, av)
        assert not (inside & outside).any()
        projected = np.maximum(lower.astype(float), np.minimum(upper.astype(float), true.astype(float)))
        oracle_sq = (true.astype(float) - projected) ** 2
        frame = pd.read_csv(Path(r0.data_root) / r0.data_file)
        split_start = len(frame) - int(len(frame) * .2)
        raw = frame.OT.to_numpy()[split_start + np.arange(n)[:, None] + np.arange(H)[None, :]][..., None]
        rebuilt = ((raw-ds.scaler.mean_[-1])/ds.scaler.scale_[-1]).astype(np.float32)
        assert np.array_equal(rebuilt, true), 'raw/training-scaler/loader alignment mismatch'
        ginfo = dict(dataset=r0.dataset, unit=r0.unit, seq_len=L, pred_len=H,
                     sample_interval_hours=.25 if r0.dataset=='PVOD' else 1.,
                     durationHours=H*(.25 if r0.dataset=='PVOD' else 1.),
                     n_windows=n, available_windows=int(present.sum()), n_points=int(av.sum()),
                     n_inside=int(inside.sum()), n_outside=int(outside.sum()),
                     n_below=int(below.sum()), n_above=int(above.sum()),
                     n_strict_outside=int((strict_below|strict_above).sum()),
                     rebuilt_truth_sha256=hashlib.sha256(true.tobytes()).hexdigest(),
                     lower_array_sha256=hashlib.sha256(lower.tobytes()).hexdigest(),
                     upper_effective_array_sha256=hashlib.sha256(upper.tobytes()).hexdigest(),
                     presence_array_sha256=hashlib.sha256(present.tobytes()).hexdigest(),
                     lower_fraction=float(below.sum()/av.sum()), upper_fraction=float(above.sum()/av.sum()),
                     outside_fraction=float(outside.sum()/av.sum()),
                     strict_lower_fraction=float(strict_below.sum()/av.sum()),
                     strict_upper_fraction=float(strict_above.sum()/av.sum()),
                     strict_outside_fraction=float((strict_below|strict_above).sum()/av.sum()),
                     oracle_mse=float(oracle_sq[av].mean()),
                     target_scaler_mean=float(ds.scaler.mean_[-1]), target_scaler_scale=float(ds.scaler.scale_[-1]),
                     minimum_span=float((upper-lower).min()), maximum_span=float((upper-lower).max()))
        distance=np.maximum(np.maximum(lower.astype(float)-true.astype(float),true.astype(float)-upper.astype(float)),0.)
        for tolerance in (0.,1e-7,1e-6,1e-5,1e-4):
            ginfo['outside_fraction_tol_'+str(tolerance)]=float(((distance>tolerance)&av).sum()/av.sum())
        geometry_rows.append(ginfo)
        for h in range(H):
            hm=av[:, h, :]
            lead_rows.append(dict(dataset=r0.dataset, unit=r0.unit, seq_len=L, pred_len=H, lead=h+1,
                n_points=int(hm.sum()), lower_fraction=float(below[:,h,:].sum()/hm.sum()),
                upper_fraction=float(above[:,h,:].sum()/hm.sum()),
                outside_fraction=float(outside[:,h,:].sum()/hm.sum()),
                oracle_mse=float(oracle_sq[:,h,:][hm].mean())))
        for r in group.itertuples(index=False):
            paths = [('checkpoint', Path(r.checkpoint_path), r.checkpoint_sha256),
                     ('prediction', Path(r.prediction_path)/'pred.npy', r.prediction_sha256),
                     ('truth', Path(r.prediction_path)/'true.npy', r.truth_sha256),
                     ('data', Path(r.data_root)/r.data_file, r.data_sha256)]
            sources = {name+'_sha256': checked_hash(path, expected) for name, path, expected in paths}
            pred = np.load(Path(r.prediction_path)/'pred.npy', mmap_mode='r')
            saved = np.load(Path(r.prediction_path)/'true.npy', mmap_mode='r')
            assert pred.shape == true.shape and np.array_equal(saved, true), r.run_id
            assert np.isfinite(pred).all()
            info={name:getattr(r,name) for name in ['run_id','dataset','unit','backbone','pathway','seq_len','pred_len','seed']}
            source_rows.append({**info, **sources, 'model':r.model, 'checkpoint_path':r.checkpoint_path, 'prediction_path':r.prediction_path, 'data_root':r.data_root, 'data_file':r.data_file, 'known_dim':K, 'truth_exact_match':True, 'scaler_reconstruction_exact':True})
            for name, mask in masks.items():
                result=score(pred, true, mask)
                metric_rows.append({**info, 'subset':name, **result,
                    'fraction_of_available': float(mask.sum()/av.sum()) if name!='unavailable' else np.nan,
                    'raw_mse':result['mse']*ds.scaler.scale_[-1]**2,
                    'raw_mae':result['mae']*ds.scaler.scale_[-1]})
            # Lead-level errors permit horizon/subset findings to be independently checked.
            for h in range(H):
                for name in ('available_all','inside','outside'):
                    result=score(pred[:,h,:],true[:,h,:],masks[name][:,h,:])
                    metric_rows.append({**info, 'subset':name+'_lead', 'lead':h+1, **result,
                        'fraction_of_available':float(masks[name][:,h,:].sum()/av[:,h,:].sum())})
            if r.pathway == 'Direct-NWP':
                violation = np.maximum(np.maximum(lower-pred, pred-upper), 0.)
                max_violation=float(violation[av].max())
                actual=score(pred,true,av)['mse']
                floor=float(oracle_sq[av].mean())
                assert max_violation <= 2e-5, (r.run_id, max_violation)
                assert actual + 1e-7 >= floor
                validation_rows.append({**info,'prediction_bound_max_abs_violation':max_violation,
                    'actual_mse':actual,'oracle_mse':floor,'truth_exact_match':True})
        print(f'[{task_index}/26] PASS {key} runs={len(group)} windows={n} outside={outside.mean():.6f} oracle={oracle_sq[av].mean():.8f}', flush=True)

    m=pd.DataFrame(metric_rows)
    m.to_csv(OUT/'seed_metrics.csv',index=False)
    pd.DataFrame(source_rows).to_csv(OUT/'checked_source_manifest.csv',index=False)
    pd.DataFrame(validation_rows).to_csv(OUT/'direct_support_checks.csv',index=False)
    g=pd.DataFrame(geometry_rows)
    g.to_csv(OUT/'unit_bounds_geometry.csv',index=False)
    gl=pd.DataFrame(lead_rows)
    gl.to_csv(OUT/'unit_lead_bounds_geometry.csv',index=False)
    gm=g.groupby(['dataset','seq_len','pred_len']).agg(
        units=('unit','nunique'),outside_fraction=('outside_fraction','mean'),
        lower_fraction=('lower_fraction','mean'),upper_fraction=('upper_fraction','mean'),
        oracle_mse=('oracle_mse','mean'),n_windows=('n_windows','sum'),
        available_windows=('available_windows','sum')).reset_index()
    sensitivity_cols=[c for c in g.columns if c.startswith('strict_') or c.startswith('outside_fraction_tol_')]
    sensitivity=g.groupby(['dataset','seq_len','pred_len'])[sensitivity_cols].mean().reset_index()
    sensitivity.to_csv(OUT/'task_boundary_tolerance_sensitivity.csv',index=False)
    gm.to_csv(OUT/'task_bounds_geometry.csv',index=False)
    gl.groupby(['dataset','seq_len','pred_len','lead'])[['outside_fraction','lower_fraction','upper_fraction','oracle_mse']].mean().reset_index().to_csv(OUT/'task_lead_bounds_geometry.csv',index=False)
    # Aggregate seeds first; never inflate samples with three identical truth arrays.
    overall=m[~m.subset.str.endswith('_lead')].copy()
    keys=['dataset','backbone','pathway','unit','seq_len','pred_len','subset']
    unit=overall.groupby(keys).agg(mse=('mse','mean'),mae=('mae','mean'),
        mse_seed_sd=('mse','std'),mae_seed_sd=('mae','std'),
        seeds=('seed','nunique'),n_points=('n_points','first')).reset_index()
    assert unit.seeds.eq(3).all()
    unit.to_csv(OUT/'unit_seed_averaged_metrics.csv',index=False)
    task=unit.groupby(['dataset','backbone','pathway','seq_len','pred_len','subset']).agg(
        mse=('mse','mean'),mae=('mae','mean'),units=('unit','nunique'),
        units_with_points=('mse','count'),n_points=('n_points','sum')).reset_index()
    task.to_csv(OUT/'task_equal_unit_metrics.csv',index=False)
    joined=task.merge(gm,on=['dataset','seq_len','pred_len'],suffixes=('','_geometry'))
    joined['oracle_fraction_of_direct_mse']=np.where(
        (joined.pathway=='Direct-NWP')&(joined.subset=='available_all'),
        joined.oracle_mse/joined.mse,np.nan)
    joined.to_csv(OUT/'task_summary.csv',index=False)
    summary={'status':'PASS','post_hoc':True,'training':False,'model_forward':False,'gpu':False,
        'frozen_runs':len(source_rows),'direct_runs':len(validation_rows),'unique_unit_tasks':len(g),
        'datasets':records.groupby('dataset').size().to_dict(),
        'all_truths_bitwise_equal_to_rebuilt':True,'all_sources_match_frozen_manifest':True,
        'max_direct_support_violation':float(pd.DataFrame(validation_rows).prediction_bound_max_abs_violation.max()),
        'available_window_fraction':float(g.available_windows.sum()/g.n_windows.sum()),
        'warning':'Hard-support oracle is a geometric lower bound, not a retrained unconstrained Direct model and not a causal decomposition of Direct/Residual differences.',
        'outputs':{p.name:sha(p) for p in sorted(OUT.glob('*.csv'))},
        'script_sha256':sha(__file__),'protocol_sha256':sha(OUT/'protocol.json')}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2),flush=True)
    build_package_tables()



def add_time_columns(frame):
    frame=frame.copy()
    frame['sample_interval_hours']=frame.dataset.map({'PVOD':.25,'GEFCom':1.})
    frame['durationHours']=frame.pred_len*frame.sample_interval_hours
    frame['backbone']=frame.backbone.replace({'WSPR history backbone':'PatchTST'}) if 'backbone' in frame else None
    return frame


def build_package_tables():
    """Derive publication tables only from the current fresh per-run reanalysis."""
    unit=pd.read_csv(OUT/'unit_seed_averaged_metrics.csv')
    geom=pd.read_csv(OUT/'unit_bounds_geometry.csv')
    task=pd.read_csv(OUT/'task_equal_unit_metrics.csv')
    direct=unit[(unit.pathway=='Direct-NWP')&(unit.subset=='available_all')].copy()
    direct=direct.rename(columns={'mse':'direct_mse','mae':'direct_mae'})
    ranged=direct.merge(geom,on=['dataset','unit','seq_len','pred_len'],validate='many_to_one',suffixes=('_run',''))
    ranged['oracle_fraction_of_direct_mse']=ranged.oracle_mse/ranged.direct_mse
    ranged['outside_percent']=100*ranged.outside_fraction
    ranged['oracle_percent_of_direct_mse']=100*ranged.oracle_fraction_of_direct_mse
    ranged=add_time_columns(ranged)
    ranged.to_csv(OUT/'output_range_by_unit.csv',index=False)
    task_direct=task[(task.pathway=='Direct-NWP')&(task.subset=='available_all')].copy()
    task_direct=task_direct.rename(columns={'mse':'direct_mse','mae':'direct_mae'})
    keys=['dataset','seq_len','pred_len']
    stats=geom.groupby(keys).agg(
        geometry_units=('unit','nunique'),outside_fraction=('outside_fraction','mean'),
        lower_fraction=('lower_fraction','mean'),upper_fraction=('upper_fraction','mean'),
        oracle_mse=('oracle_mse','mean'),n_available_points=('n_points','sum'),
        n_outside=('n_outside','sum'),n_inside=('n_inside','sum'),
        n_below=('n_below','sum'),n_above=('n_above','sum'),n_windows=('n_windows','sum')).reset_index()
    task_range=task_direct.merge(stats,on=keys,validate='many_to_one')
    task_range['oracle_fraction_of_direct_mse']=task_range.oracle_mse/task_range.direct_mse
    task_range['outside_percent']=100*task_range.outside_fraction
    task_range['outside_fraction_pooled_points']=task_range.n_outside/task_range.n_available_points
    task_range['oracle_percent_of_direct_mse']=100*task_range.oracle_fraction_of_direct_mse
    task_range=add_time_columns(task_range)
    assert len(task_range)==8 and len(ranged)==52
    task_range.to_csv(OUT/'output_range_by_task.csv',index=False)
    conditional=[]
    for level,frame in [('unit_seed_average',unit),('task_unit_equal',task)]:
        q=frame[frame.subset.isin(['available_all','inside','outside','below','above','unavailable'])].copy()
        q['aggregation_level']=level
        conditional.append(q)
    cond=add_time_columns(pd.concat(conditional,ignore_index=True,sort=False))
    cond['classification_tolerance_standardized']=1e-6
    cond.to_csv(OUT/'conditional_errors.csv',index=False)

    comparison=[]
    if ARGS.reference_dir:
        for name in ['checked_source_manifest.csv','direct_support_checks.csv','seed_metrics.csv',
                     'unit_bounds_geometry.csv','task_bounds_geometry.csv',
                     'task_boundary_tolerance_sensitivity.csv','unit_seed_averaged_metrics.csv',
                     'task_equal_unit_metrics.csv','task_summary.csv']:
            ref=ARGS.reference_dir/name
            fresh=pd.read_csv(OUT/name)
            prior=pd.read_csv(ref)
            # Compare every pre-existing field, preserving original numerical definitions.
            assert len(fresh)==len(prior),(name,len(fresh),len(prior))
            for col in prior.columns:
                assert col in fresh.columns,(name,col)
                a,b=fresh[col],prior[col]
                if pd.api.types.is_numeric_dtype(a) and pd.api.types.is_numeric_dtype(b):
                    ok=np.allclose(a.to_numpy(float),b.to_numpy(float),rtol=1e-12,atol=1e-14,equal_nan=True)
                    maxdiff=float(np.nanmax(np.abs(a.to_numpy(float)-b.to_numpy(float)))) if (a.notna()&b.notna()).any() else 0.
                else:
                    ok=a.fillna('<NA>').astype(str).equals(b.fillna('<NA>').astype(str));maxdiff=None
                assert ok,('Original v2 mismatch',name,col,maxdiff)
                comparison.append(dict(reference_file=name,column=col,status='PASS',max_absolute_numeric_difference=maxdiff))
    pd.DataFrame(comparison).to_csv(OUT/'reference_v2_comparison.csv',index=False)

    expected={('PVOD',16):4.99,('PVOD',96):6.23,('GEFCom',24):3.35,('GEFCom',96):2.57}
    publication=[]
    for r in task_range.itertuples(index=False):
        target=expected[(r.dataset,r.pred_len)]
        assert round(r.outside_percent,2)==target
        publication.append(dict(dataset=r.dataset,backbone=r.backbone,pred_len=int(r.pred_len),
          sample_interval_hours=r.sample_interval_hours,durationHours=r.durationHours,
          recomputed_outside_percent=r.outside_percent,manuscript_outside_percent=target,
          matches_two_decimal_publication=True,
          oracle_percent_of_direct_mse=r.oracle_percent_of_direct_mse))
    pv=task_range[task_range.dataset=='PVOD'].oracle_percent_of_direct_mse
    assert round(pv.min(),2)==29.44 and round(pv.max(),2)==37.92
    pd.DataFrame(publication).to_csv(OUT/'publication_value_checks.csv',index=False)
    summary=json.loads((OUT/'summary.json').read_text())
    summary['s29_publication_value_check']='PASS'
    summary['original_v2_all_existing_numeric_columns_check']='PASS' if comparison else 'NOT_REQUESTED'
    summary['output_range_unit_rows']=len(ranged)
    summary['output_range_task_rows']=len(task_range)
    summary['conditional_error_rows']=len(cond)
    summary['outputs']={p.name:sha(p) for p in sorted(OUT.glob('*.csv'))}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print('S29 fresh-array verification and publication checks PASS',flush=True)

if __name__=='__main__':
    main()
